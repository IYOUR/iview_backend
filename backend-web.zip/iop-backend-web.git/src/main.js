import Vue from 'vue';
import iView from 'iview';
import router from './router'; //路由
import store from './store'; //数据存储
import components from './components'; //公共组件
import codes from './commons/utils/code';//静态码，消息等。
import * as filters from './commons/filters'; //过滤函数
import * as directives from './commons/directives';//公共指令

import './api/axios.config'; //请求工具
import 'iview/dist/styles/iview.css'; //iview 样式
// import '../static/iconfont/iconfont.css';//iconfont
// import './mock';//模拟数据

Vue.config.productionTip = false; //生产环境提示信息

Object.keys(codes).forEach(key=> Vue.prototype[key] = codes[key]);//extends for prototype
Object.keys(filters).forEach(function (k) {Vue.filter(k, filters[k]);});//reg filters
Object.keys(components).forEach(function (k) {Vue.component(k, components[k]);});//reg components
Object.keys(directives).forEach(function (k) {Vue.directive(k, directives[k]);});//reg directives

Vue.use(iView);

new Vue({router,store}).$mount('#app');