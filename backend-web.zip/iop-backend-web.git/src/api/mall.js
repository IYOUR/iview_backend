/**
 * @file mall.js
 * Created by haner on 2017/5/10.
 * @brief
 */

import axios from 'axios';
import * as UserService from './user';
import CommonState from '../store/commonState';

//获取车场列表
export const getParksList = () => axios.post(`${axios.PARK_API}/parks`).then(res => res);

//待审查列表
export const getCheckingList = params => {
    !params && (params = {});
    params.page_items = params. page_items || CommonState.PAGER.page_items;
    return axios.post(`${axios.PARK_API}/card/waite_for_apply`, params).then(res => res)
};

//修改审批记录
export const updateChecking = checking => axios.post(`${axios.PARK_API}/card/modify_apply`, checking).then(res => res);

//获取审批记录
export const getApplyRecords = params => {
    !params && (params = {});
    params.page_items = CommonState.PAGER.page_items;
    return axios.post(`${axios.PARK_API}/card/apply_records`, params).then(res => res);
};

//获取消费记录
export const getConsumeList = params => {
    params.page_items = CommonState.PAGER.page_items;
    return axios.post(`${axios.PARK_API}/card/orders`, params).then(res => res);
};

//卡类型相关接口
export const getCardTypes = params => axios.post(`${axios.PARK_API}/card_types`, params).then(res => res);
export const saveOrUpdateCardType = cradType => axios.post(`${axios.PARK_API}/card_types/${cradType.id ? 'update' : 'create'}`, cradType).then(res => res);

//卡配置相关
export const getCardConfigList = params => {
    !params && (params = {});
    params.park_code = UserService.getUserSelectPark().park_code;
    return axios.post(`${axios.PARK_API}/card_confs`, params).then(res => res);
};

//保存或更新卡配置
export const saveOrUpdateCardConfig = cardConfig => axios.post(`${axios.PARK_API}/card_confs/${cardConfig.card_conf_id ? 'update' : 'create'}`, cardConfig).then(res => res);

// 删除审批记录
export const removeChecking = params => axios.post(`${axios.PARK_API}/card/remove_apply`, params).then(res => res);

//获取卡图标
export const getCardIcons = params => axios.get(`${axios.PARK_API}/card/icon_list`, {params: params}).then(res => res);
