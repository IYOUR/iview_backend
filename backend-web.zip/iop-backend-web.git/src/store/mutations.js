/**
 * @file mutations
 * Created by haner on 2017/4/5.
 * @brief
 */

import * as types from './mutation-types';

export default {
    [types.GET_CARD_TYPES_LIST](state, data){
        state.cardTypes = data;
    },

    [types.GET_PARK_LIET](state, data){
        state.carParks = data;
    },

    [types.GET_CARD_CONFIG_LIST](state, data){
        state.cardConfigs = data;
    },

    [types.CHANGE_ACTIVE_PARK](state,park){
        state.activePark = park;
    }
}
