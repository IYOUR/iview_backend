/**
 * @file mutation-types
 * Created by haner on 2017/3/28.
 */


//卡类型
export const GET_CARD_TYPES_LIST = 'GET_CARD_TYPES_LIST';

//卡配置
export const GET_CARD_CONFIG_LIST = 'GET_CARD_CONFIG_LIST';

//车场列表
export const GET_PARK_LIET = 'GET_PARK_LIET';

//修改当前车场
export const CHANGE_ACTIVE_PARK = 'CHANGE_ACTIVE_PARK';