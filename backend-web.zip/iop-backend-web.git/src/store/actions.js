/**
 * @file actions
 * Created by haner on 2017/3/27.
 */
import * as types from './mutation-types';
import * as MallService from '../api/mall';
import {HTTP_STATUS} from '../commons/utils/code';

export default {
    //获取卡类型
    getCardTypes({commit},params){
        return MallService.getCardTypes(params).then(res => {
            res.code === HTTP_STATUS.SUCCESS.CODE && commit(types.GET_CARD_TYPES_LIST, res.data.items);
            return res;
        });
    },
    //获取车场列表
    getParkList({commit}){
        return MallService.getParksList().then(res => {
            res.code === HTTP_STATUS.SUCCESS.CODE && commit(types.GET_PARK_LIET, res.data);
            return res;
        });
    },
    //获取卡配置
    getCardConfigs({commit}){
        return MallService.getCardConfigList().then(res => {
            res.code === HTTP_STATUS.SUCCESS.CODE && commit(types.GET_CARD_CONFIG_LIST, res.data.items);
            return res;
        });
    },
}
