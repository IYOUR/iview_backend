/**
 * @file commonState
 * Created by haner on 2017/5/15.
 * @brief
 */
import * as UserService from '../api/user';

export default {
    //项目中用户的所有状态
    userStatus: [
        {text: '正常', value: '0'},
        {text: '删除', value: '1'},
        {text: '禁用', value: '2'}
    ],

    //用户的所有类型
    userTypes: [
        {text: '集团管理', value: '1'},
        {text: '集团子管理', value: '2'},
    ],

    //分页信息
    PAGER: {
        page_items: 15
    },

    //购买渠道
    PAY_CHANNEL: [
        {text: 'wechat', value: 0},
        {text: '停车王app', value: 1},
        {text: '小程序', value: 2},
    ],

    //审批状态
    CHECKING_STATUS: [
        {text: '未审批', value: '0'},
        {text: '已审批', value: '1'},
        {text: '被拒绝', value: '2'},
        {text: '已过期', value: '3'},
    ],

    //卡类型
    cardTypes: [],

    //卡配置
    cardConfigs: [],

    //车场列表
    carParks: [],

    //当前所选车场
    activePark: {},

    //卡状态
    cardStatus: [
        {text: '正常', value: '1'},
        {text: '已下架', value: '0'},
    ],

    //卡有效期单位
    cardUnit: [
        {text: '月', value: '1'},
        {text: '天', value: '2'},
        {text: '整周', value: '3'},
        {text: '周内', value: '4'},
        {text: '周末', value: '5'},
    ],

    //是否审核
    isChecking: [
        {text: '是', value: '1'},
        {text: '否', value: '0'},
    ],

    // 支付方式类型
    PAYOUT_TYPE: [
        {
            value: '1',
            text: '全部',
        },
        {
            value: '2',
            text: '现金',
        },
        {
            value: '3',
            text: '微信',
        },
        {
            value: '4',
            text: '支付宝',
        },
        {
            value: '5',
            text: '停车王钱包',
        },
        {
            value: '6',
            text: '银联',
        },
        {
            value: '7',
            text: '其他',
        }
    ],
    
    // 进出类别
    SORT_LIST: [
        {
            value: '1',
            text: '全部',
        },
        {
            value: '2',
            text: '进车量',
        },
        {
            value: '3',
            text: '出车量',
        },
    ]
};
