
import Total from '../views/total/index.vue';
import ChargeContainer from '../views/total/charge/ChargeContainer.vue';
import PayoutContainer from '../views/total/payout/PayoutContainer.vue';
import TrafficContainer from '../views/total/traffic/TrafficContainer.vue';

export default {
    path: 'total', component: Total, name:'iop.total', redirect:{name:'iop.total.charge'},
    children: [
        {path: 'charge', name: 'iop.total.charge', component: ChargeContainer},
        {path: 'payout', name: 'iop.total.payout', component: PayoutContainer},
        {path: 'traffic', name: 'iop.total.traffic', component: TrafficContainer}
    ]
}
