
import Group from '../views/group/index.vue';
import Index from '../views/group/userManagement/index.vue';
import EditUserContainer from '../views/group/userManagement/editUserContainer.vue';
import AddUserContainer from '../views/group/userManagement/addUserContainer.vue';

export default {
    path: 'group', component: Group, name:'iop.group', redirect:{name:'iop.group.edit'},
    children: [
	        {path: 'edit', name: 'iop.group.edit', component: EditUserContainer},
	        {path: 'add', name: 'iop.group.add', component: AddUserContainer},
   		]
	}