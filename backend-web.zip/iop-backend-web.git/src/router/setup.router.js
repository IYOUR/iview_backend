import Setup from '../views/setup/index.vue';
import RevisePasswordContainer from '../views/setup/revisePassword/RevisePasswordContainer.vue';

export default {
    path: 'setup', component: Setup, name:'iop.setup', redirect:{name:'iop.setup.revisePassword'},
    children: [
	        {path: 'revisePassword', name: 'iop.setup.revisePassword', component: RevisePasswordContainer}
   		]
	}