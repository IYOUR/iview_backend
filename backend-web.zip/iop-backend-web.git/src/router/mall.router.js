/**
 * @file mall.router
 * Created by haner on 2017/4/5.
 * @brief
 */


import MallIndex from '../views/mall/MallIndexContainer.vue';
import CardIndex from '../views/mall/card/CardIndexContainer.vue';
import CheckingContainer from '../views/mall/checking/CheckingContainer.vue';
import CardConfigContainer from '../views/mall/card/CardConfigContainer.vue';
import CardTypeContainer from '../views/mall/card/CardTypeContainer.vue';
import ConsumeContainer from '../views/mall/consume/ConsumeContainer.vue';
import RecordContainer from '../views/mall/record/RecordContainer.vue';

export default {
    path: 'mall', component: MallIndex, name: 'iop.mall', redirect: {name: 'iop.mall.checking'},
    children: [
        {path: 'checking', name: 'iop.mall.checking', component: CheckingContainer},
        {path: 'consume', name: 'iop.mall.consume', component: ConsumeContainer},
        {path: 'record', name: 'iop.mall.record', component: RecordContainer},
        {
            path: 'card', name: 'iop.mall.card', component: CardIndex, redirect: {name: 'iop.mall.card.config'},
            children: [
                {path: 'config', name: 'iop.mall.card.config', component: CardConfigContainer},
                {path: 'type', name: 'iop.mall.card.type', component: CardTypeContainer},
            ]
        },

    ]
}