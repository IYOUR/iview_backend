import Vue from 'vue'
import Router from 'vue-router';

//Containers
import Login from '../views/Login.vue';
import App from '../views/App.vue';

//Children Router
import MallRouter from './mall.router';
import GroupRouter from './group.router';
import TotalRouter from './total.router';
import SetupRouter from './setup.router';

//Other Logic Code
import {isLogin} from '../api/user';

/**
 * 路由配置
 * @type {[*]}
 */
const routes = [

    //
    {path: '/login', name: 'iop.login', component: Login, meta: {ignore: true}},

    //Main
    {
        path: '/', name: 'iop.app', component: App, redirect: {name: 'iop.total'},
        children: [
            GroupRouter,
            TotalRouter,
            SetupRouter,
            MallRouter,
        ]
    },
];


const router = new Router({routes});


//用户信息过滤
router.beforeEach((to, from, next) => {
    if (to.matched.some(record => !record.meta.ignore) && !isLogin()) {
        next({path: '/login'});
    } else {
        if (to.path === '/login' && isLogin()) {
            next({path: to.query.redirect || '/'});
        } else {
            next();
        }
    }
});


Vue.use(Router);
export default router


