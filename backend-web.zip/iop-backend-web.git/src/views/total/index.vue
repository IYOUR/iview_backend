<template>
    <div class="total-container">
        <div class="navs">
            <router-link class="navs-item" :to="{ name: 'iop.total.charge'}" active-class="active">收费情况</router-link>
            <router-link class="navs-item" :to="{ name: 'iop.total.payout'}" active-class="active">支付方式</router-link>
            <router-link class="navs-item" :to="{ name: 'iop.total.traffic'}" active-class="active">车流量</router-link>
        </div>
        <router-view></router-view>
    </div>
</template>