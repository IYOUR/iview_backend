 <template>
    <div class="total">
        <!-- 查询开始 -->
       <div class="demand">
            <Form inline :model="searchParam" >
            <Row>
                <i-col span="8">
                    <!-- 日期查询开始 -->
                    <Form-item label="查询日期:" 
                               :label-width="80" 
                               class="date">
                        <Date-picker class="total-child-date"  
                                      format="yyyy/MM/dd" 
                                      type="daterange" 
                                      placeholder="选择日期" 
                                      v-model="searchParam.date">
                        </Date-picker>
                    </Form-item>
                    <!-- 日期查询结束 -->
                </i-col>
                <i-col span="6">
                    <!-- 车场开始 -->
                    <Form-item label="车场:"
                               :label-width="60" 
                               class="park">
                        <Tooltip content="支持选择多个车场对比哦..." placement="top-start">
                            <Select multiple 
                                    class="total-child-select" 
                                    v-model="searchParam.parkSelect">
                                <Option v-for="item in carList" 
                                        :value="item.value" 
                                        :key="item">
                                        {{ item.label }}
                                </Option>
                            </Select>
                        </Tooltip>
                    </Form-item>
                    <!-- 车场结束 -->
                </i-col>
                <i-col span="6">
                     <!-- 支付方式开始 -->
                    <Form-item label="支付:"
                               :label-width="60" 
                               class="payout">
                        <Tooltip content="支持选择多个方式对比哦..." 
                                  placement="top-start">
                            <Select placeholder="全部" 
                                    multiple
                                    v-model="searchParam.payoutSelect">
                                <Option v-for="item in payoutList" 
                                        :value="item.value" 
                                        :key="item">
                                        {{ item.text }}
                                </Option>
                            </Select>
                         </Tooltip>
                    </Form-item>
                    <!-- 支付方式结束 -->
                </i-col>
                <i-col span="4">
                     <!-- 查询按钮开始 -->
                    <Form-item :label-width="50" class="btn">
                         <Button html-type="submit" @click="totalDemand">查询</Button>
                    </Form-item>
                    <!-- 查询按钮结束 -->
                </i-col>
           </Row> 
           </Form>
       </div>
       <!-- 查询结束 -->
        <!-- 图表开始 -->
       <div class="chart-border clearfix" v-cloak>
            <div id="annularChart" 
                 class="annularChart" 
                 :style="{width:'35%',height:'400px'}" 
                 v-bind:class="{ 'nextStyle': seat, 'afterStyle': !seat}">
            </div>
            <div id="barGraph" 
                 :style="{width:'60%',height:'400px'}"  
                 v-bind:class="{hidebarGraph: showbarGraph}">
            </div>
       </div>
       <!-- 表格开始 -->
       <div class="table" v-cloak>
            <div class="clearfix">
                <a @click="tableDownload" class="btnDownload">导出为CSV</a>
             </div>
           <Table :columns="columns" 
                  :data="tableData" 
                  size="small" 
                  ref="table">
           </Table>
            <p class="table-info">只显示近30条记录，完整数据请导出CSV文件</p>
       </div>
       <!-- 表格结束 -->
    </div>
</template>
<script>
    // 引入接口
    import * as ParkService from '../../../api/total';
    import * as TableService from '../../../api/total';
    import axios from 'axios';
    import {isLogin} from '../../../api/user';
    // 引入echarts
    import echarts from "echarts";

    import CommonState from '../../../store/commonState';

    export default {
        created(){
            this.getParksList().then(carList => {
               this.setDefault();
               this.totalDemand();
            });
        },
        computed: {},
        methods: {
            //获取车场列表
            getParksList() {
               return ParkService.getParksList(this.ParksListParams || {}).then(res => {
                    let data = [];
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    };
                    for(let i = 0; i < res.data.length; i++){
                        let obj = {};
                        obj.label = res.data[i].parking_name;
                        obj.value = res.data[i].park_code;
                        data[i] = obj;
                    };
                  return this.carList = data;
                 });
            }, 
             //获取支付情况
            getPaymentInfo() {
                 TableService.getPaymentInfo(this.paramsProcess()).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    };
                    let annularChartData = res.data.pie_chart_data;
                    let barGraphData = res.data.bar_chart_data;
                    let xData = [];
                    //数据格式处理
                    for(let i = 0; i < barGraphData.series.length; i++){
                        let item = barGraphData.series[i];
                        xData.push(item.stack);
                        item.type = 'bar';
                        item.label = { normal: { show: true } };
                    };
                    //更新表格数据
                    this.tableData = res.data.table_data;
                    //更新环形图数据
                    this.annularChartOptions = Object.assign({},this.annularChartOptions,{
                       series:[{
                            type:'pie',
                            radius: ['35%', '65%'],
                            label: {
                                normal: {
                                    position:'inside',
                                    formatter: '{d}%',
                                },
                            },
                            data: annularChartData,
                        }],
                       legend: {
                            icon: 'circle',
                            itemHeight: 8,
                            itemWidth: 8,
                            textStyle: {
                                fontSize: 10,
                            },
                            left:'center',
                            bottom:20,
                            data: res.data.legend,
                        }
                    });
                    // 更新堆叠柱状图数据
                    this.barGraphOptions = Object.assign({},this.barGraphOptions,{
                        series: barGraphData.series,
                        xAxis:{
                         data: barGraphData.xAxis,
                        },
                        legend: {
                            icon: 'circle',
                            itemHeight: 8,
                            itemWidth: 8,
                            textStyle: {
                                fontSize: 10,
                            },
                            top: 20,
                            x: 'right',
                            data: res.data.legend,
                        },
                    });
                 });
            },
            //格式化日期
            changeDate(now){
                let year = now.getFullYear();     
                let month = now.getMonth()+1;     
                let date = now.getDate();  
                return year+"-"+month+"-"+date;  
            },
            //参数处理
            paramsProcess(){
                let searchParam = Object.assign({},this.searchParam),params = {};
                params.park_code_list = searchParam.parkSelect.join(',');
                params.query_date_begin = this.changeDate(searchParam.date[0]);
                params.query_date_end = this.changeDate(searchParam.date[1]);
                params.payment_channel = searchParam.payoutSelect.join(',');
                return params;
            },
             //查询数据
            totalDemand(){
                if(this.searchParam.date == ""||this.searchParam.parkSelect == ""||this.searchParam.payoutSelect == ""){
                    this.$Message.success('请选择查询数据!');
                    return ;
                };
                this.getPaymentInfo();

               if(this.searchParam.parkSelect.length >1){
                    this.showbarGraph = false;
                    this.seat = true;
                    return;
               };
               if(this.searchParam.parkSelect.length <2){
                    this.showbarGraph = true;
                    this.seat = false;
                    return;
               };
            },
            //导出数据
            tableDownload (){
                let paramsData = this.paramsProcess();
                let params = "";
                for (let Key in paramsData){
                    params = params+'&'+''+Key+'='+paramsData[Key]+'';
                };
                window.open(`${axios.PARK_API}/download_payment?token=${isLogin() + params}`);
            },
            // 设置默认参数
            setDefault(){
                this.searchParam.date = [new Date(),new Date()];
                this.searchParam.parkSelect = [this.carList[0].value];
                this.searchParam.payoutSelect = [this.payoutList[0].value];
                return this.searchParam;
            },
        },
        mounted() {
            //环形图
            this.annularChart = echarts.init(document.getElementById('annularChart'));
            //柱状图
            this.barGraph = echarts.init(document.getElementById('barGraph'));
        },
        watch:{
            'annularChartOptions':{
                deep:true,
                handler:function(newOption,oldOption){
                    this.annularChart.setOption(newOption);
                },
            },
            'barGraphOptions':{
                deep:true,
                handler:function(newOption,oldOption){
                    this.barGraph.setOption(newOption);
                },
            },
        },
         data () {
            return {
                showbarGraph: true,
                seat: false,
                 //搜索条件
                searchParam:{
                    date: [],
                    parkSelect: [],
                    payoutSelect: [],
                },
                //车场列表
                carList: [],
                //支付方式类型
                payoutList: CommonState.PAYOUT_TYPE,
                 //环形图数据 
                annularChart: null,
                annularChartOptions: {
                    tooltip: {
                        formatter: "{b}: {c} ({d}%)",
                    },
                    textStyle: {
                        fontSize: 10,
                    },
                    legend: {
                        data:[],
                    },
                    color: ['#fdce3a','#6adf74',' #209af9','#fba131','#46c9e5','#c0d0dd'],
                    series: [
                        {
                            data:[],
                        }
                    ]
                },
                //柱状图数据
                barGraph: null,
                barGraphOptions: {
                    title: {
                        text: '支付方式',
                        left: "3%",
                        textStyle: {
                            fontWeight: 'normal',
                        }
                    },
                    color: ['#fdce3a','#6adf74',' #209af9','#fba131','#46c9e5','#c0d0dd'],
                    tooltip : {
                        trigger: 'item',
                        formatter: '{b}<br />{a}: {c}',
                        axisPointer : {   
                            type : '' ,       
                        }
                    },
                    legend: {
                        data: [],
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true,
                    },
                    yAxis:  {
                        type: 'value',
                    },
                     xAxis :{
                            data :[],
                    },
                    series: [],
                 },
                //表头内容
                columns: [
                   {
                        title: "日期",
                        key: "date",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "车场",
                        key: "parking_name",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "现金",
                        key: "cash",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "微信",
                        key: "wechat",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "支付宝",
                        key: "alipay",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                     {
                        title: "停车王",
                        key: "wallet",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "银联",
                        key: "unionpay",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "其他",
                        key: "other",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "总计",
                        key: "total",
                        align: "center",
                        className: 'demo-table-info-column',
                    }
                ],
                //表中数据
                tableData: [],
             }
        }
    }
</script>