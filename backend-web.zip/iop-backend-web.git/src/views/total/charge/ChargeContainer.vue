<template>
    <div class="total">
        <!-- 查询开始 -->
        <div class="demand">
             <Form inline :model="searchParam">
             <Row>
                <i-col span="8">
                    <!-- 日期查询开始 -->
                    <Form-item label="查询日期:" 
                               :label-width="80" 
                               class="date">
                        <Date-picker class="total-child-date" 
                                     format="yyyy/MM/dd" 
                                     type="daterange" 
                                     placeholder="选择日期"
                                     v-model="searchParam.date">
                        </Date-picker>
                    </Form-item>
                    <!-- 日期查询结束 -->
                </i-col>
                <i-col span="6">
                     <!-- 车场开始 -->
                    <Form-item label="车场:"
                               :label-width="60" 
                               class="park">
                        <Tooltip content="支持选择多个车场对比哦..." placement="top-start">
                            <Select multiple 
                                    class="total-child-select" 
                                    v-model="searchParam.parkSelect">
                                <Option v-for="item in carList" 
                                        :value="item.value" 
                                        :key="item">
                                        {{ item.label }}
                                </Option>
                            </Select>
                        </Tooltip>
                    </Form-item>
                    <!-- 车场结束 -->
                </i-col>
                <i-col span="6">
                     <!-- 区分人员开始 -->
                    <Form-item label="是否区分收费人员:" 
                               :label-width="140" 
                               class="switch">
                        <i-switch v-model="searchParam.switch" 
                                  :disabled="searchParam.parkSelect.length !== 1">
                        </i-switch>
                    </Form-item>
                    <!-- 区分人员结束 -->
                </i-col>
                <i-col span="4">
                    <!-- 查询按钮开始 -->
                    <Form-item :label-width="50" class="btn">
                        <Button html-type="submit" @click="totalDemand">查询</Button>
                    </Form-item>
                    <!-- 查询按钮结束 -->
                </i-col>
            </Row>
            </Form>
        </div>
        <!-- 查询结束 -->
        <!-- 图表开始 -->
        <div class="chart clearfix" v-cloak>
            <Row>
                <Radio-group v-model="searchParam.radioData" 
                             type="button" 
                             class="radio-btn">
                    <Radio label="日纬度"></Radio>
                    <Radio label="月纬度"></Radio>
                </Radio-group>
            </Row>
            <Row>
                <div id="lineChart" :style="{width:'100%',height:'400px'}"></div>
            </Row>
        </div>
        <!-- 图表结束 -->
        <!-- 表格开始 -->
        <div class="table" v-cloak>
            <div class="clearfix">
                <a @click="tableDownload" class="btnDownload">导出为CSV</a>
            </div>
            <Table :columns="columns" 
                   :data="tableData" 
                   size="small" 
                   ref="table">
            </Table>
            <p class="table-info">只显示近30条记录，完整数据请导出CSV文件</p>
        </div>
        <!-- 表格结束 -->
    </div>
</template>
<script>
    //引入接口
    import * as ParkService from '../../../api/total';
    import * as TableService from '../../../api/total';
    import axios from 'axios';
    import {isLogin} from '../../../api/user';
    //引入echarts
    import echarts from "echarts";

    export default {
        created () {
            this.getParksList().then(() => {
                this.setDefault();
                this.totalDemand();
            });
        },
        computed: {},
        methods: {
            //获取车场列表
            getParksList() {
                return ParkService.getParksList(this.ParksListParams || {}).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    };
                    let data = [];
                    for (let i = 0; i < res.data.length; i++) {
                        let obj = {};
                        obj.label = res.data[i].parking_name;
                        obj.value = res.data[i].park_code;
                        data[i] = obj;
                    };
                    this.carList = data;
                });
            },
            //获取收费情况
            getChargeInfo() {
                TableService.getChargeInfo(this.paramsProcess()).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    };
                    //更新表格数据
                    this.tableData = res.data.table_data;
                    let chartsDatas = res.data.line_chart_data;
                    //数据格式处理
                    for (let i = 0; i < chartsDatas.series.length; i++) {
                        let item = chartsDatas.series[i];
                        item.type = 'line';
                        item.stack = '总量';
                    };
                    this.echartOptions = Object.assign({}, this.echartOptions, {
                        series: chartsDatas.series,
                        xAxis: {
                            data: chartsDatas.xAxis,
                        },
                        legend: {
                            textStyle: {
                                fontSize: 10,
                            },
                            top: 20,
                            x: 'right',
                            data: chartsDatas.legend,
                        },
                    });
                });
            },
            //格式化日期
            changeDate(now){
                let year = now.getFullYear();
                let month = now.getMonth() + 1;
                let date = now.getDate();
                return year + "-" + month + "-" + date;
            },
            //参数处理
            paramsProcess(){
                let searchParam = Object.assign({}, this.searchParam), params = {};
                params.park_code_list = searchParam.parkSelect.join(',');
                params.query_date_begin = this.changeDate(searchParam.date[0]);
                params.query_date_end = this.changeDate(searchParam.date[1]);
                params.charge_taker_related = new Number(searchParam.switch).valueOf().toString();
                params.query_duration = searchParam.radioData == "日纬度" ? "day" : "mon";
                //多个车场时收费员为“0”
                if (params.park_code_list.split(",").length > 1) {
                    params.charge_taker_related = "0";
                    this.disabled = false;
                }
                return params;
            },
            //查询数据
            totalDemand(){
                if (this.searchParam.date == "" || this.searchParam.parkSelect == "" || this.searchParam.radioData == "") {
                    this.$Message.success('请选择查询数据!');
                    return;
                };
                let charger = {
                        title: "收费员",
                        key: "charger",
                        align: "center",
                        className: 'demo-table-info-column'
                    };
               if(this.searchParam.switch == true){
                    if(this.columns.length < 5){
                        this.columns.push(charger);
                    };
                };
                this.getChargeInfo();
            },
            //导出数据
            tableDownload (){
                let paramsData = this.paramsProcess();
                let params = "";
                for (let Key in paramsData) {
                    params = params + '&' + '' + Key + '=' + paramsData[Key] + '';
                };
                window.open(`${axios.PARK_API}/download_charges?token=${isLogin() + params}`);
            },
            // 设置默认参数
            setDefault(){
                this.searchParam.date = [new Date(), new Date()];
                this.searchParam.parkSelect = [this.carList[0].value];
                this.searchParam.radioData = '日纬度';
                this.searchParam.switch = false;
                return this.searchParam;
            },
        },
        //折线图
        mounted() {
            this.lineChart = echarts.init(document.getElementById('lineChart'));
        },
        watch: {
            'echartOptions': {
                deep: true,
                handler: function (newOption, oldOption) {
                    this.lineChart.setOption(newOption);
                },
            },
        },
        data () {
            return {
                disabled: false,
                //搜索条件
                searchParam: {
                    date: [],
                    parkSelect: [],
                    radioData: "",
                    switch: false,
                },
                lineChart: null,
                //折线图数据
                echartOptions: {
                    title: {
                        text: '收费情况',
                        textStyle: {
                            fontWeight: 'normal',
                        },
                        left: "3%",
                    },
                    color: ['#fdce3a','#6adf74',' #209af9','#fba131','#46c9e5','#c0d0dd'],
                    tooltip: {
                        trigger: 'axis',
                    },
                    legend: {
                        data: [],
                    },
                    grid: {
                        left: '3%',
                        right: '5%',
                        bottom: '10%',
                        containLabel: true,
                    },
                    xAxis: {
                        boundaryGap: false,
                        data: [],
                    },
                    yAxis: {
                        type: 'value',
                    },
                    series: [
                        {
                            name: '',
                            type: 'line',
                            stack: '总量',
                            data: [],
                        },
                    ]
                },
                //车场列表
                carList: [],
                //单选框
                radioData: '日纬度',
                //表头内容
                columns: [
                    {
                        title: "日期",
                        key: "time",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "车场",
                        key: "parking_name",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "应收",
                        key: "calc_charge",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "实收",
                        key: "parking_charge",
                        align: "center",
                        className: 'demo-table-info-column',
                    }
                ],
                //表中数据
                tableData: [],
            }
        }
    }
</script>