 <template>
    <div class="total">
        <!-- 查询开始 -->
       <div class="demand">
            <Form inline :model="searchParam"> 
            <Row>
                <i-col span="8">
                    <!-- 日期查询开始 -->
                    <Form-item label="查询日期:" 
                               :label-width="80" 
                               class="date">
                         <Date-picker class="total-child-date"  
                                      format="yyyy/MM/dd" 
                                      type="daterange" 
                                      placeholder="选择日期" 
                                      v-model="searchParam.date">
                         </Date-picker>
                    </Form-item>
                    <!-- 日期查询结束 -->
                </i-col>
                <i-col span="6">
                    <!-- 车场开始 -->
                    <Form-item label="车场:"
                               :label-width="60" 
                               class="park">
                        <Tooltip content="支持选择多个车场对比哦..." 
                                 placement="top-start">
                            <Select multiple  
                                    placeholder="选择多个车场" 
                                    class="total-child-select" 
                                    v-model="searchParam.parkSelect">
                                <Option v-for="item in carList" 
                                        :value="item.value" 
                                        :key="item">
                                        {{ item.label }}
                                </Option>
                            </Select>
                        </Tooltip>
                    </Form-item>
                    <!-- 车场结束 -->
                </i-col>
                <i-col span="6">
                     <!-- 进出类别 开始-->
                    <Form-item label="进出类别:"
                               :label-width="80" 
                               class="sort">
                        <Select placeholder="全部" 
                                class="total-child-select" 
                                v-model="searchParam.importTypeSelect">
                            <Option v-for="item in sortList" 
                                    :value="item.value" 
                                    :key="item">
                                    {{ item.text }}
                            </Option>
                        </Select>
                    </Form-item>
                    <!-- 进出类别结束 -->
                </i-col>
                <i-col span="4">
                    <!-- 查询按钮开始 -->
                    <Form-item :label-width="50" class="btn">
                         <Button html-type="submit" @click="totalDemand">查询</Button>
                    </Form-item>
                    <!-- 查询按钮结束 -->
                </i-col>
            </Row>
            </Form> 
       </div>
       <!-- 查询结束 -->
        <!-- 图表开始 -->
       <div class="chart" v-cloak>
            <Row>
                <Radio-group v-model="searchParam.radioData" 
                             type="button" 
                             class="radio-btn">
                    <Radio label="天纬度"></Radio>
                    <Radio label="小时纬度"></Radio>
                </Radio-group>    
            </Row>
            <Row>
                <div id="lineChart" 
                     :style="{width:'100%',height:'400px'}">
                </div>
            </Row>
       </div>
       <!-- 图表结束 -->
       <div class="table" v-cloak>
            <div class="clearfix">
                <a @click="tableDownload" class="btnDownload">导出为CSV</a>
             </div>
            <Table :columns="columns" 
                   :data="tableData" 
                   size="small" 
                   ref="table">
            </Table>
            <p class="table-info">只显示近30条记录，完整数据请导出CSV文件</p>
       </div>
       <!-- 表格结束 -->
    </div>
</template>
<script>
    // 引入接口
    import * as ParkService from '../../../api/total';
    import * as TableService from '../../../api/total';
    import axios from 'axios';
    import {isLogin} from '../../../api/user';
    import CommonState from '../../../store/commonState'; 
    // 引入echarts
    import echarts from "echarts";

    export default {
        created(){
          this.getParksList().then(carList => {
               this.setDefault();
               this.totalDemand();
            });
        },
        computed: {},
        methods: {
            //获取车场列表
            getParksList() {
                return  ParkService.getParksList(this.ParksListParams || {}).then(res => {
                    let data = [];
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    };
                    for(let i = 0; i < res.data.length; i++){
                        let obj = {};
                        obj.label = res.data[i].parking_name;
                        obj.value = res.data[i].park_code;
                        data[i] = obj;
                    };
                    this.carList = data;
                 });
            }, 
             //获取车流量情况
            getTrafficInfo() {
                 TableService.getTrafficInfo(this.paramsProcess()).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    };
                    //更新表格数据
                    this.tableData = res.data.table_data;
                    let chartsDatas = res.data.line_chart_data;
                    //数据格式处理
                    for(let i = 0; i<chartsDatas.series.length; i++){
                        let item = chartsDatas.series[i];
                        item.type = 'line';
                        item.stack = '总量';
                    };
                    //更新折线图数据
                    this.echartOptions = Object.assign({},this.echartOptions,{
                        series: chartsDatas.series,
                        xAxis:{
                            data:chartsDatas.xAxis,
                        },
                        legend:{
                            formatter: function (name) {
                                return echarts.format.truncateText(name, 50, '10px Microsoft Yahei', '…');
                            },
                            tooltip: {
                                show: true,
                            },
                            x: 'right',
                            textStyle: {
                                fontSize: 10,
                            },
                            top: 20,
                            data:chartsDatas.legend,
                        },
                    });
                 });
            },
            //格式化日期
            changeDate(now){
                let year = now.getFullYear();     
                let month = now.getMonth()+1;     
                let date = now.getDate();  
                return year+"-"+month+"-"+date;  
            },
            //参数处理
            paramsProcess(){
                let searchParam = Object.assign({},this.searchParam),params = {};
                params.park_code_list = searchParam.parkSelect.join(',');
                params.query_date_begin = this.changeDate(searchParam.date[0]);
                params.query_date_end = this.changeDate(searchParam.date[1]);
                params.time_duration = searchParam.radioData == "天纬度" ? "day" : "hour";
                params.in_out = searchParam.importTypeSelect;
                return params;
            },
             //查询数据
            totalDemand(){
                 if(this.searchParam.date == ""||this.searchParam.parkSelect == ""||this.searchParam.radioData == ""||this.searchParam.importTypeSelect == ""){
                    this.$Message.success('请选择查询数据!');
                    return ;
                };
                this.searchParam.radioData == "小时纬度" ? this.columns[0].title = "小时" : this.columns[0].title = "日期";
                this.getTrafficInfo();
            },
            //导出数据
            tableDownload (){
                let paramsData = this.paramsProcess();
                let params = "";
                for (let Key in paramsData){
                  params = params+'&'+''+Key+'='+paramsData[Key]+'';
                };
                window.open(`${axios.PARK_API}/download_traffic?token=${isLogin() + params}`);
            },
            // 设置默认参数
            setDefault(){
                this.searchParam.date = [new Date(),new Date()];
                this.searchParam.parkSelect = [this.carList[0].value];
                this.searchParam.radioData = '天纬度';
                this.searchParam.importTypeSelect = this.sortList[0].value;
                return this.searchParam;
            },
        },
         mounted() {
            //折线图
            this.lineChart = echarts.init(document.getElementById('lineChart'));
        },
        watch:{
            'echartOptions': {
                deep:true,
                handler:function(newOption,oldOption){
                    this.lineChart.setOption(newOption);
                },
            },
        },
         data () {
            return {
                //搜索条件
                searchParam: {
                    date: [],
                    parkSelect: [],
                    radioData: "",
                    importTypeSelect: [],
                },
                //车场列表
                carList: [],
                //单选框
                radioData: '天纬度',
                lineChart: null,
                //折线图数据
                echartOptions: {
                    title: {
                        text: '车流量',
                        textStyle: {
                            fontWeight: 'normal'
                        },
                        left: "3%",
                    },
                    color: ['#fdce3a','#6adf74',' #209af9','#fba131','#46c9e5','#c0d0dd'],
                    tooltip: {
                        trigger: 'axis',
                    },
                    legend: {
                        data: [],
                    },
                    grid: {
                        left: '3%',
                        right: '5%',
                        bottom: '10%',
                        containLabel: true,
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        data: []
                    },
                    yAxis: {
                        type: 'value',
                    },
                    series: [],
                },
                //进出类别
                sortList: CommonState.SORT_LIST,
                //表头内容
                 columns: [
                     {
                        title: "日期",
                        key: "time",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "车场",
                        key: "parking_name",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "进车总数",
                        key: "in",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "出车总数",
                        key: "out",
                        align: "center",
                        className: 'demo-table-info-column',
                    },
                    {
                        title: "临时车进/出",
                        align: "center",
                        className: 'demo-table-info-column',
                        render (row, column, index) {
                            return row.tempory_car_in + '/' + row.tempory_car_out;
                        },
                    },
                    {
                        title: "月租车进/出",
                        align: "center",
                        className: 'demo-table-info-column',
                        render (row, column, index) {
                            return row.month_car_in + '/' + row.month_car_out;
                        },
                    },
                    {
                        title: "免费车进/出",
                        align: "center",
                        className: 'demo-table-info-column',
                        render (row, column, index) {
                            return row.free_car_in + '/' + row.free_car_out;
                        },
                    },
                    {
                        title: "储时车进/出",
                        align: "center",
                        className: 'demo-table-info-column',
                        render (row, column, index) {
                            return row.hours_car_in + '/' + row.hours_car_out;
                        },
                    },
                    {
                        title: "储值车进/出",
                        align: "center",
                        className: 'demo-table-info-column',
                        render (row, column, index) {
                            return row.fee_car_in + '/' + row.fee_car_out;
                        },
                    },
                    {
                        title: "其他类进/出",
                        align: "center",
                        className: 'demo-table-info-column',
                        render (row, column, index) {
                            return row.other_car_in + '/' + row.other_car_out;
                        },
                    },
                ],
                // 表中数据
                tableData: [],
             }
        },
    }
</script>