<template>
    <div class="group-container">
        <div class="navs">
            <router-link class="navs-item" :to="{}" active-class="active">用户管理</router-link>
        </div>
        <router-view></router-view>
    </div>
</template>