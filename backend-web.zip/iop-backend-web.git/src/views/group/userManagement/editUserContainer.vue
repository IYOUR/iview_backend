<template>
    <div class="editUser-container clearfix">
        <div class="userList">
            <span>用户列表</span>
            <router-link :to="{ name: 'iop.group.add'}" class="addBtn">新建</router-link>
        </div>
        <div class="table">
            <Table stripe 
                   :columns="columns" 
                   :data="tableData.items">
            </Table>
        </div>
        <!-- 模态框开始 -->
        <Modal v-model="isEdit" 
               title="编辑用户信息" 
               @on-ok="submitUserMessage">
            <Form :label-width="80" :model="currentEditUser">
                <Form-item label="用户名：">
                    <i-input placeholder="请输入" v-model="currentEditUser.username"></i-input>
                </Form-item>
                <Form-item label="电话：">
                    <i-input placeholder="请输入" v-model="currentEditUser.phone"></i-input>
                </Form-item>
            </Form>
        </Modal>
        <!-- 模态框结束 -->
        <!-- 分页开始 -->
        <div style="margin: 10px 0;overflow: hidden">
            <div class="fr">
                <Page :total="parseInt(tableData.item_amount,10)"
                      @on-change="onNextPageBtnClick">
               </Page>
            </div>
        </div>
        <!-- 分页结束 -->
    </div> 
</template>
<script>
    //引入接口
    import * as GetUserService from '../../../api/group'; 
    import * as EditUserService from '../../../api/group';

    export default {
        created(){
            this.getUser();
            console.log(this.$store);
        },
        methods: {
            //获取集团用户信息
            getUser() {
                GetUserService.getUsers(this.userParams).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    }
                    for(let i = 0; i < res.data.items.length; i++){
                        let user = res.data.items[i];
                        if(user.ustatus == "0"){
                            user.ustatusText = "正常";
                        }
                        if(res.data.items[i].ustatus == "1"){
                            res.data.items[i].ustatusText = "删除";
                        }
                         if(res.data.items[i].ustatus == "2"){
                            res.data.items[i].ustatusText = "禁用";
                        }
                        if(res.data.items[i].utype == "2"){
                            res.data.items[i].utypeText = "集团管理员";
                        }
                        if(res.data.items[i].utype == "1"){
                            res.data.items[i].utypeText = "集团子管理员";
                        }
                    }
                    this.tableData = res.data;
                });
            },
             //分页按钮点击
            onNextPageBtnClick(page){
                this.userParams.page = page;
                this.getUser();
            },
            //编辑用户信息
            onClickEditUserBtn(index){
                this.isEdit = true;
                this.currentEditUser = this.tableData.items[index];
            },
            // 提交信息
            submitUserMessage() {
               delete this.currentEditUser.utypeText;
               delete this.currentEditUser.ustatusText;
                EditUserService.editUser( this.currentEditUser).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    }
                   this.$Message.info('保存成功！');
                });
            },
            // 删除用户信息
            removeUserMessage(index) {
                 let removeUserData = this.tableData.items[index];
                 removeUserData.power = '{"100":{"001","002","003"},"101":{"001","002","003"}}';
                 delete removeUserData.utypeText;
                 delete removeUserData.ustatusText;
                 removeUserData.ustatus = '1';
                 EditUserService.editUser(removeUserData).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    }
                });
                this.tableData.items.splice(index, 1);
            }
        },
        computed:{

        },
        data () {
            return {
                // 参数设置
                userParams: {
                    page: this.page || 1
                },
                edit: false,
                columns: [
                    {
                        title: '用户名',
                        key: 'username',
                        align: 'center',
                        className: 'demo-table-info-column'
                    },
                    {
                        title: '电话',
                        key: 'phone',
                        align: 'center',
                        className: 'demo-table-info-column'
                    },
                    {
                        title: '邮箱',
                        key: 'email',
                        align: 'center',
                        width: 200,
                        className: 'demo-table-info-column'
                    },
                    {
                        title: '账户类型',
                        key: 'utypeText',
                        align: 'center',
                        className: 'demo-table-info-column'
                    },
                    {
                        title: '状态',
                        key: 'ustatusText',
                        align: 'center',
                        className: 'demo-table-info-column'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        align: 'center',
                        className: 'demo-table-info-column',
                        render (row, column, index) {
                           return `<i-button type="primary" size="small" @click="onClickEditUserBtn(${index})">编辑</i-button> <i-button type="error" size="small" @click="removeUserMessage(${index})">删除</i-button>`;
                        }
                    }
                ],
                // 表格数据
                tableData: [],
                // 是否编辑
                isEdit : false,
                currentEditUser:{},
            }
        }
    }
</script>
