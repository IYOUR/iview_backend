<template>
	  <div class="addUser-container">
        <Form ref="addUserForm" 
              :model="addUserParam" 
              :rules="ruleValidate" 
              label-position="right" 
              :label-width="100">
            <Form-item label="姓名：" 
                       class="addUser-form" 
                       prop="uname">
                <Input class="uname" 
                       v-model="addUserParam.uname" 
                       type="text"></Input>
            </Form-item>
            <Form-item label="密码：" 
                       class="addUser-form" 
                       prop="password">
                <Input class="password" 
                       v-model="addUserParam.password" 
                       type="password"></Input>
            </Form-item>
            <Form-item label="手机号：" 
                        class="addUser-form" 
                        prop="phone">
                <Input class="phone" v-model="addUserParam.phone"></Input>
            </Form-item>
            <hr class="line">
            <Form-item label="所辖车场：" 
                       class="addUser-form yard" 
                       prop="park">
                <Checkbox-group v-model="addUserParam.park">
                    <Checkbox v-for="item in carList" 
                              :key="item" 
                              :label="item.value">
                      {{item.label}}
                    </Checkbox>
                </Checkbox-group>
            </Form-item>
            <Form-item class="addUser-form">
               <Button type="primary" 
                       class="confirm" 
                       @click="handleSubmit('addUserParam')">确认</Button>
               <router-link :to="{ name: 'iop.group.edit'}" class="cancel">取消</router-link>
            </Form-item>
        </Form> 
        </div>
</template>

<script>
    //引入接口
    import * as ParkService from '../../../api/total';
    import * as AddUserService from '../../../api/group';
    import * as CheckUserService from '../../../api/group';

	export default {
        computed: {},
        created () {
            this.getParksList();
        },
        methods: {
             //获取车场列表
            getParksList() {
                return  ParkService.getParksList(this.ParksListParams || {}).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    }
                    let data = [];
                    for(let i = 0; i < res.data.length; i++){
                        let obj = {};
                        obj.label = res.data[i].parking_name;
                        obj.value = res.data[i].park_code;
                        data[i] = obj;
                    }
                    this.carList = data;
                 });
            }, 
            // 新建用户
            handleSubmit (addUserParam) {
                this.$refs.addUserForm.validate(valid=>{
                if(!valid) {return}
                    AddUserService.createUser(this.paramsProcess()).then(res => {
                if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                    this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                    return;
                }
                if(res.code == "1003"){
                    this.$Message.success('用户名存在，请重新输入！');
                }
                 this.$Message.success('创建成功！');
                 this.$router.push('/group/edit');
                })
            });
            },
            //参数处理
            paramsProcess(){
                let addUserParam = Object.assign({},this.addUserParam),params = {};
                params.username = addUserParam.uname;
                params.password = addUserParam.password;
                params.email = addUserParam.email;
                params.phone = addUserParam.phone;
                params.park_codes = addUserParam.park.join(',');
                params.power = addUserParam.controll;
                return params;
            }
        },
        data () {
            return {
                //车场列表
                carList: [],
                addUserParam: {
                    uname: '',
                    password: '',
                    email: 'sss@qq.com',
                    phone: '',
                    park: [],
                    controll: '{"100":{"001","002","003"},"101":{"001","002","003"}}'
                },
                // 校验
                ruleValidate: {
                    uname: [
                        { required: true, message: '姓名不能为空', trigger: 'blur' },
                        { type: 'string', min: 1, message: '姓名不能为空', trigger: 'blur' },
                        { type: 'string', max: 18, message: '姓名不能超过18位', trigger: 'blur' }
                    ],
                    password: [
                        { required: true, message: '请填写密码', trigger: 'blur' },
                        { type: 'string', min: 6, message: '密码长度不能小于6位', trigger: 'blur'},
                        { type: 'string', max: 16, message: '密码长度不能超过16位', trigger:'blur' }
                    ],
                    phone: [
                            {required: true, message: '手机号码不能为空', trigger: 'blur'},
                            {
                                type: 'string',
                                pattern: /^((13|14|15|17|18)[0-9]{1}\d{8})$/,
                                message: '手机号码格式不正确',
                                trigger: 'blur'
                            }
                        ],
                    park: [
                        { required: true, type: 'array', min: 1, message: '至少选择一个车场', trigger: 'change' }
                    ]
                }
            }
        }
    }
</script>