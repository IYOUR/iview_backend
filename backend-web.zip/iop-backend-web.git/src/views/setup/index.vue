<template>
    <div class="setup-container">
        <div class="navs">
            <router-link class="navs-item" :to="{}" active-class="active">修改密码</router-link>
        </div>
        <router-view></router-view>
    </div>
</template>