<template>
    <div class="revise-container">
        <Form :model="formCustom" 
              :rules="ruleCustom" 
              label-position="right" 
              :label-width="110">
            <Form-item label="旧密码：" 
                       class="revise-form" 
                       prop="oldPasswd">
                <Input type="password" 
                       v-model="formCustom.oldPasswd">
                </Input>
            </Form-item>
            <Form-item label="新密码：" 
                       class="revise-form"  
                       prop="password">
                <Input  type="password" 
                        v-model="formCustom.password">
                </Input>
            </Form-item>
            <Form-item label="确认新密码：" 
                       class="revise-form" 
                       prop="passwdCheck">
                <Input type="password" 
                       v-model="formCustom.passwdCheck">
                </Input>
            </Form-item>
            <Form-item class="revise-form">
                <Button type="primary" 
                        @click="handleSubmit('formCustom')"
                        class="confirm" >
                        确认
                </Button>
                <Button type="ghost" 
                        @click="handleReset('formCustom')" 
                        style="margin-left: 8px"
                        class="cancel">
                        取消
                </Button>
            </Form-item>
        </Form>
    </div>
</template>
<script>
    // 引入接口
    import * as setupPwdService from '../../../api/user';
    
    export default {
        created(){},
        computed: {},
        methods: {
            // 提交数据
            handleSubmit (name) {
               setupPwdService.setUpPwd(this.paramsProcess() || {}).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.ERROR.MSG);
                        return;
                    };
                    if(res.code == "1"){
                        this.$Message.success('密码修改成功！');
                        this.formCustom.oldPasswd = "";
                        this.formCustom.password = "";
                        this.formCustom.passwdCheck = "";
                    };
                });
            },
             //参数处理
            paramsProcess(){
                let setupPwdParam = Object.assign({},this.formCustom),params = {};
                params.oldpwd  = setupPwdParam.oldPasswd;
                params.newpwd  = setupPwdParam.password;
                params.newpwd_ag  = setupPwdParam.passwdCheck;
                return params;
            },
            // 重置数据
            handleReset () {
               this.formCustom.oldPasswd = "";
               this.formCustom.password = "";
               this.formCustom.passwdCheck = "";
            },
        },
         data () {
            return {
                formCustom: {
                    oldPasswd: '',
                    password: '',
                    passwdCheck: '',
                },
                ruleCustom: {
                    oldPasswd: [
                        { required: true, message: '请填写密码', trigger: 'blur' }
                    ],
                    password: [
                        { required: true, message: '请填写密码', trigger: 'blur' },
                        { type: 'string', min: 6, message: '字数超限，请输入6-16位密码', trigger: 'blur'},
                        { type: 'string', max: 16, message: '字数超限，请输入6-16位密码', trigger:'blur' }
                    ],
                    passwdCheck: [
                        { required: true, message: '请确认密码', trigger: 'blur' }
                    ],
                }
            }
        }
    }
</script>