<template>
    <div class="login-container">
        <Row>
            <i-col span="12">
                <img class="login-left-img" src="../assets/image/img-login-left@2X.png" alt="图片无法正常加载。请刷新重试！">
            </i-col>
            <i-col span="12" class-name="login-right-form">
                <Form ref="formValidate">
                    <div class="ivu-form-item">
                        <img class="logo"
                             src="../assets/image/logo.png"
                             alt="图片加载失败，请刷新重试！">
                        <span class="system-name">停车王智慧管理系统</span>
                    </div>
                    <Form-item>
                        <Input placeholder="用户名" v-model="loginParams.username"></Input>
                    </Form-item>
                    <Form-item>
                        <Input type="password" placeholder="密码" v-model="loginParams.password"></Input>
                    </Form-item>
                    <Form-item>
                        <Button long
                                html-type="submit"
                                :loading="isLogin"
                                @click.prevent="login">
                            <span v-if="!isLogin">登录</span>
                            <span v-else>登录中...</span>
                        </Button>
                    </Form-item>
                </Form>
            </i-col>
        </Row>
    </div>
</template>
<style lang="scss">@import "../assets/stylesheet/index";</style>
<script>
    import * as UserService from '../api/user';
    import Storage from '../commons/utils/storage';

    export default {
        methods: {
            //校验
            validate () {
                if(!this.loginParams.username || !this.loginParams.username.trim()){
                    return '请输入用户名！';
                }
                if(!this.loginParams.password || !this.loginParams.password.trim()){
                     return '请输入密码！';
                }
                return '';
            },
            //登录
            login() {
                let msg='';
                if(msg = this.validate()){
                    this.$Message.info(msg);
                    return;
                }
                this.isLogin = true;
                UserService.login(this.loginParams).then(res => {
                    this.isLogin = false;
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.success(res.message || this.HTTP_STATUS.SERVER_ERROR.MSG);
                        return;
                    }
                    Storage.set(Storage.KEYS.USER,res.data);
                    this.$Message.success('登录成功！');
                    this.$router.push('/');
                }).catch(error => {
                    this.isLogin = false;
                });
            },
        },
        watch: {},
        data () {
            return {
                loginParams: {
                    username:'',
                    password:'',
                },
                isLogin: false
            }
        }
    }
</script>
