<template>
    <div class="mall-container">
        <div class="navs">
            <router-link class="navs-item" :to="{ name: 'iop.mall.checking'}" active-class="active">待审核</router-link>
            <router-link class="navs-item" :to="{ name: 'iop.mall.consume'}" active-class="active">消费记录</router-link>
            <router-link class="navs-item" :to="{ name: 'iop.mall.card'}" active-class="active">配置管理</router-link>
            <router-link class="navs-item" :to="{ name: 'iop.mall.record'}" active-class="active">审批记录</router-link>
        </div>
        <router-view></router-view>
    </div>
</template>

