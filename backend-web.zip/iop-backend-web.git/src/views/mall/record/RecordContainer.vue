<template>
    <div class="record">
        <Row class="search-list">
            <Form :label-width="80">
                <Row>
                    <i-col span="4">
                        <Form-item label="车牌号：">
                            <i-input placeholder="请输入" v-model="customSearchParam.vpl"></i-input>
                        </Form-item>
                    </i-col>
                    <i-col span="4">
                        <Form-item label="审核状态：">
                            <Select placeholder="请选择" v-model="customSearchParam.apply_status">
                                <Option :value="-1">全部</Option>
                                <Option v-for="(item,index) in checkingStatus"
                                        :value="item.value" :key="index"
                                        v-text="item.text"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                    <i-col span="4">
                        <Form-item label="卡名称：">
                            <Select placeholder="请选择" v-model="customSearchParam.card_id">
                                <Option :value="-1">全部</Option>
                                <Option v-for="(item,index) in cardConfigs"
                                        :value="item.card_conf_id" :key="index"
                                        v-text="item.card_name"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                    <i-col span="4">
                        <Form-item label="停车场：" class="park">
                            <Select multiple placeholder="请选择" v-model="customSearchParam.park_code_list">
                                <Option v-for="(item,index) in carParks"
                                        :value="item.park_code" :key="index"
                                        v-text="item.parking_name || '未命名车场'"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                    <i-col span="4">
                        <Form-item label="审批时间：">
                            <Date-picker type="datetimerange"
                                         v-model="customSearchParam.handle_time"
                                         placement="bottom-end"
                                         format="yyyy-MM-dd HH:mm"
                                         placeholder="选择日期"></Date-picker>
                        </Form-item>
                    </i-col>
                    <i-col span="4" style="padding-left: 20px;">
                        <Button type="ghost"
                                @click.native="onSearchBtnClick">
                            搜索
                        </Button>
                        <Button type="ghost" @click="download">导出</Button>
                        <a @click="launch" class="launch fr">
                            <img class="pull"
                                 src="..../../../src/assets/image/icon-down@3X.png"
                                 alt="图片无法正常加载，请刷新重试">
                        </a>
                    </i-col>
                </Row>
                <Row v-if="isShow">
                    <i-col span="4">
                        <Form-item label="车主：">
                            <i-input placeholder="请输入" v-model="searchParam.owner_name"></i-input>
                        </Form-item>
                    </i-col>
                    <i-col span="4">
                        <Form-item label="联系电话：">
                            <i-input placeholder="请输入" v-model="searchParam.mobile"></i-input>
                        </Form-item>
                    </i-col>
                    <i-col span="4">
                        <Form-item label="有效期：">
                            <Date-picker type="datetimerange"
                                         v-model="searchParam.expire_time"
                                         placement="bottom-end"
                                         format="yyyy-MM-dd HH:mm"
                                         placeholder="选择日期"></Date-picker>
                        </Form-item>
                    </i-col>

                </Row>
            </Form>
        </Row>
        <Row class="enlarge clearfix">
            <i-col span="12">
                <span>审批记录详情（{{res.item_amount || 0}}）</span>
            </i-col>
            <i-col span="12">
                <a class="large" @click="large">放大</a>
            </i-col>
        </Row>
        <div class="record-table">
            <Table stripe :columns="columns" :data="res.items"></Table>
            <div style="margin: 10px 0;overflow: hidden">
                <div class="fr">
                    <Page :total="parseInt(res.item_amount,10)"
                          :pageSize="pager.page_items"
                          :current="searchParam.page"
                          @on-change="onNextPageBtnClick"></Page>
                </div>
            </div>
        </div>
        <div class="dask">
            <Row class="enlarge clearfix">
                <i-col span="12">
                    <span>审批记录详情（{{res.item_amount || 0}}）</span>
                </i-col>
                <i-col span="12">
                    <a class="small" @click="narrow">退出</a>
                </i-col>
            </Row>
            <div class="record-table">
                <Table stripe
                       :columns="columns"
                       :data="res.items">
                </Table>
            </div>
        </div>
        <Modal title="编辑审核记录"
               v-model="isEditChecking"
               :closable="false"
               :loading="loading"
               @on-ok="onCheckingFromSubmit"
               :mask-closable="false">
            <CheckingEdit :checking="currentEditChecking" ref="checkingFrom"></CheckingEdit>
        </Modal>

    </div>
</template>
<script>

    import {mapState, mapActions} from 'vuex';
    import * as MallService from '../../../api/mall';
    import CommonState from '../../../store/commonState';
    import CheckingEdit from './components/CheckingEdit.vue';
    import axios from 'axios';
    import {isLogin} from '../../../api/user';

    export default {
        components: {
            CheckingEdit,
        },

        created(){
            this.getParkList();
            this.getCardConfigs();
            this.getCheckingList(this.buildSearchParam());
        },
        methods: {

            ...mapActions({
                getCardTypes: 'getCardTypes',
                getParkList: 'getParkList',
                getCardConfigs: 'getCardConfigs',
            }),
            //参数构建
            buildSearchParam(searchParam){
                this.searchParam = Object.assign({}, this.searchParam, searchParam);
                this.searchParam.expire_time_start = this.searchParam.expire_time[0] ? moment(this.searchParam.expire_time[0]).format('YYYY-MM-DD') : '';
                this.searchParam.expire_time_end = this.searchParam.expire_time[1] ? moment(this.searchParam.expire_time[1]).format('YYYY-MM-DD') : '';
                this.searchParam.handle_time_start = this.customSearchParam.handle_time[0] ? moment(this.customSearchParam.handle_time[0]).format('YYYY-MM-DD') : '';
                this.searchParam.handle_time_end = this.customSearchParam.handle_time[1] ? moment(this.customSearchParam.handle_time[1]).format('YYYY-MM-DD') : '';
                this.searchParam.park_code_list = this.customSearchParam.park_code_list.join(',');
                this.searchParam.apply_status = this.customSearchParam.apply_status !== -1 ? this.customSearchParam.apply_status : '';
                this.searchParam.card_id = this.customSearchParam.card_id !== -1 ? this.customSearchParam.card_id : '';
                this.searchParam.owner_name = this.searchParam.owner_name ? this.searchParam.owner_name : '';
                this.searchParam.mobile = this.searchParam.mobile ? this.searchParam.mobile : '';
                this.searchParam.vpl = this.customSearchParam.vpl ? this.customSearchParam.vpl : '';
                return this.searchParam;
            },
            //获取审核列表
            getCheckingList(searchParam){
                MallService.getApplyRecords(searchParam).then(res => {
                    this.res = res.data;
                });
            },
            //搜索按钮点击
            onSearchBtnClick(){
                this.getCheckingList(this.buildSearchParam());
            },
            //分页按钮点击
            onNextPageBtnClick(page){
                this.getCheckingList(this.buildSearchParam({page: page}));
            },
            //编辑审查记录
            // onCheckingEditBtnClick(index){
            //     this.isEditChecking = true;
            //     this.currentEditChecking = this.res && this.res.items[index];
            // },
            //删除审查记录
            onCheckingRemoveBtnClick(index){
                this.currentEditChecking = this.res && this.res.items[index];
                this.$Modal.confirm({
                    content: '<h3>确认删除该记录？</h3>',
                    onOk: () => {
                        this.res.items.splice(index, 1);
                        MallService.removeChecking(this.currentEditChecking).then(res => {
                            this.currentEditChecking = {};
                        });
                    }
                });
            },
            onCheckingFromSubmit(){
                this.$refs.checkingFrom.submit((valid, checking) => {
                    if (!valid) {
                        this.loading = false;
                        setTimeout(() => {
                            this.loading = true
                        }, 100);
                    }
                    valid && MallService.updateChecking(checking).then(res => {
                        this.isEditChecking = false;
                        this.currentEditChecking = {};
                    }).catch(err => this.isEditChecking = false);
                });
            },
            // 表格放大
            large(){
                let dask = document.getElementsByClassName('dask')[0];
                dask.style.visibility = "visible";
            },
            // 表格缩小
            narrow(){
                let dask = document.getElementsByClassName('dask')[0];
                dask.style.visibility = "hidden";
            },
            // 搜索栏展开
            launch(){
                this.isShow = !this.isShow;
                if (!this.isShow) {
                    document.getElementsByClassName('pull')[0].style.transform = 'rotateY(180deg)';
                }
                else {
                    document.getElementsByClassName('pull')[0].style.transform = 'rotateX(180deg)';
                }
            },
            // 表格导出
            download(){
                let paramsData = this.buildSearchParam();
                for (let i in paramsData) {
                    if (paramsData[i] === "") {
                        delete paramsData[i];
                    }
                }
                let params = "";
                for (let Key in paramsData) {
                    params = params + '&' + '' + Key + '=' + paramsData[Key] + '';
                }
                window.open(`${axios.PARK_API}/card/download_apply?token=${isLogin() + params}`);
            }

        },
        computed: {
            ...mapState({
                pager: 'PAGER',
                checkingStatus: 'CHECKING_STATUS',
                cardTypes: 'cardTypes',
                cardConfigs: 'cardConfigs',
                carParks: 'carParks',
            }),
        },
        data () {
            return {
                isShow: false,
                // 表格表头数据
                columns: [
                    {
                        title: '停车场名称',
                        key: 'parking_name',
                        align: 'center'
                    },
                    {
                        title: '卡名称',
                        key: 'card_name',
                        align: 'center'
                    },
                    {
                        title: '车牌号',
                        key: 'vpl',
                        align: 'center'
                    },
                    {
                        title: '车主姓名',
                        key: 'owner_name',
                        align: 'center'
                    },
                    {
                        title: '联系电话',
                        key: 'mobile',
                        align: 'center'
                    },
                    {
                        title: '有效期',
                        key: 'effectiveTime',
                        align: 'center',
                        render: function (row) {
                            if(row.expire_start == '' || row.expire_end == ''){
                                return '--'
                            }
                            return `${row.expire_start}至${row.expire_end}`;
                        }
                    },
                    {
                        title: '地址',
                        key: 'address',
                        align: 'center'
                    },
                    {
                        title: '审批状态',
                        key: 'apply_status',
                        align: 'center',
                        render(row){
                            let status = CommonState.CHECKING_STATUS.find(item =>    item.value + '' === row.apply_status);
                            return status ? status.text : '--';
                        }
                    },
                    {
                        title: '审批时间',
                        key: 'handle_time',
                        align: 'center'
                    },
                    {
                        title: '提交时间',
                        key: 'createon',
                        align: 'center'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        align: 'center',
                        render (row, column, index) {
                            return `<i-button type="text" size="small" @click="onCheckingRemoveBtnClick(${index})">删除</i-button>`;
                        }
                    }
                ],
                //审核列表
                res: {},
                //自定义搜索条件
                customSearchParam: {
                    vpl: '',
                    park_code_list: [],
                    handle_time: [],
                    card_id: -1,
                    apply_status: -1,
                },
                //搜索条件
                searchParam: {
                    page: 1,
                    expire_time: [],
                    mobile: '',
                    owner_name: '',
                },
                isEditChecking: false,
                loading: true,
                currentEditChecking: {},
            }
        }
    }
</script>
