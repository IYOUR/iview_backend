<template>
    <div class="check-detail">
        <div class="list-group">
            <div class="list-group-item">
                <i class="iconfont irain-edit fr" style="cursor: pointer;font-size: 20px;"
                   @click.navive="onEditBtnClick"></i>
                <div class="image">
                    <img :src="checking.ico_type">
                    <div class="desc">
                        <p>年包卡类型</p>
                        <p>车牌号：<span v-text="checking.vpl"></span></p>
                    </div>
                </div>
            </div>
            <div class="list-group-item">申请审批时间：{{checking.handle_time | formatDate}}</div>
        </div>

        <div class="list-group">
            <p class="title">车主信息</p>
            <div class="list-group-item">
                <div class="input-group">
                    <label>车主姓名：</label>
                    <label v-text="checking.owner_name"></label>
                </div>

                <div class="input-group">
                    <label>手机号码：</label>
                    <label v-text="checking.mobile"></label>
                </div>

                <div class="input-group">
                    <label>车位号码：</label>
                    <label v-text="checking.parking_no"></label>
                </div>

                <div class="input-group">
                    <label>联系邮箱：</label>
                    <label v-text="checking.email"></label>
                </div>

                <div class="input-group">
                    <label>详细住址：</label>
                    <label v-text="checking.address"></label>
                </div>

            </div>
        </div>

        <div class="list-group-btn">
            <Button type="info" @click.navite="onCheckingPassBtnClick">&nbsp;通过&nbsp;</Button>
            <Button type="ghost" @click.navite="onCheckingNotPassBtnClick">不通过</Button>
        </div>
    </div>
</template>

<script>
    import * as MallService from '../../../../api/mall';

    export default{

        props: {
            checking: {
                type: Object,
                default: function () {
                    return {};
                }
            }
        },

        methods: {
           //审核通过
            onCheckingPassBtnClick(){
                this.checking.apply_status = '1';
                this.submit();
            },
             //审核不通过
            onCheckingNotPassBtnClick(){
                this.checking.apply_status = '2';
                this.submit();
            },
            //编辑
            onEditBtnClick(){
                this.$emit('onEditBtnClick', true);
            },
            submit(){
                MallService.updateChecking(this.checking).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message);
                        return;
                    }
                    this.$emit('onRefresh');
                });
            }
        },
        
    }
</script>
