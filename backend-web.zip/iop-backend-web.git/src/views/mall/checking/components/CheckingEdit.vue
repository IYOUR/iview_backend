<template>
    <div class="check-detail">
        <div class="list-group">
            <div class="list-group-item">
                <div class="image">
                    <img :src="checking.ico_type">
                    <div class="desc">
                        <p>年包卡类型</p>
                        <p>车牌号：<span v-text="checking.vpl"></span></p>
                    </div>
                </div>
            </div>
            <div class="list-group-item">
                申请审批时间：{{checking.handle_time | formatDate}}
            </div>
        </div>
        <div class="list-group">
            <p class="title">车主信息</p>
            <div class="list-group-item info">
                <Form :model="checking" 
                      :label-width="100" 
                      ref="checkingEditForm" 
                      :rules="ruleValidate">
                    <Form-item label="车主姓名：" prop="owner_name">
                        <Input v-model="checking.owner_name"></Input>
                    </Form-item>
                    <Form-item label="手机号码：" prop="mobile">
                        <Input v-model="checking.mobile"></Input>
                    </Form-item>
                    <Form-item label="车位号码：" prop="parking_no">
                        <Input v-model="checking.parking_no"></Input>
                    </Form-item>
                    <Form-item label="联系邮箱：" prop="email">
                        <Input v-model="checking.email"></Input>
                    </Form-item>
                    <Form-item label="详细住址：" prop="address">
                        <Input v-model="checking.address"></Input>
                    </Form-item>
                </Form>
            </div>
        </div>
        <div class="list-group-btn">
            <Button type="info" @click.navite="onCheckingPassBtnClick">&nbsp;确定&nbsp;</Button>
            <Button type="ghost" @click.navite="onCheckingNotPassBtnClick">取消</Button>
        </div>
    </div>
</template>

<script>
    import * as MallService from '../../../../api/mall';
    export default{
        props: {
            checking: {
                type: Object,
                default: function () {
                    return {};
                }
            }
        },
        methods: {
            //提交数据
            onCheckingPassBtnClick(){
                this.submit();
                this.$Message.success('修改成功！');
            },
             //取消按钮
            onCheckingNotPassBtnClick(){
                this.$emit('onRefresh');
            },

            submit(){
                this.$refs.checkingEditForm.validate(valid => {
                    valid && MallService.updateChecking(this.checking).then(res => {
                        if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                            this.$Message.error(res.message);
                            return;
                        }
                        this.$emit('onRefresh');
                    });
                });
            }
        },

        data(){
            return {
                //是否审核中
                isChecking: false,

                ruleValidate: {
                    owner_name: [
                        {required: true, message: '车主姓名不能为空', trigger: 'blur'}
                    ],
                    mobile: [
                        {required: true, message: '手机号码不能为空', trigger: 'blur'},
                        {
                            type: 'string',
                            pattern: /^((13|14|15|17|18)[0-9]{1}\d{8})$/,
                            message: '手机号码格式不正确',
                            trigger: 'blur'
                        }
                    ],
                    email: [
                        {required: true, message: '邮箱不能为空', trigger: 'blur'},
                        {type: 'email', message: '邮箱格式不正确', trigger: 'blur'},
                    ],
                    parking_no: [
                        {required: true, message: '车位号不能为空', trigger: 'blur'},
                        {type: 'string', max: 20, message: '车位号不能超过20位'}
                    ],
                    address: [
//                        {len:30,message:'地址过长'}
                    ],
                }
            };
        },
    }
</script>
