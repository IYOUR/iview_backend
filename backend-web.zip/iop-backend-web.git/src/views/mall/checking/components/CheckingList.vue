<template>
    <div>
        <!--搜索框-->
        <row class="checking-search">
            <i-col span="20">
                <i-input class="icon-left"
                         icon="ios-search"
                         placeholder="请输入..."
                         v-model="searchParam.key_words"></i-input>
            </i-col>
            <i-col span="4">
                <Button class="no-border"
                        icon="loop"
                        @click="onRefreshBtnClick">
                </Button>
            </i-col>
        </row>
        <!--列表-->
        <div class="checking-list" 
             @scroll="onScroll($event)">
            <div class="checking-item"
                 :class="[{'active': item.id===currentChecking.id}]"
                 v-for="(item, index) in checkingList"
                 @click="onClickCheckingItem(item,index)">
                <div class="image">
                    <img :src="item.ico_type" alt="" width="100%">
                </div>
                <div class="content">
                    <p class="title" v-text="item.vpl"></p>
                    <div class="description clearfix">
                        <span class="label fl" v-text="item.card_name"></span>
                        <span class="date fr">{{item.update_time|formatDate}}</span>
                    </div>
                </div>
            </div>
            <div class="checking-item text-center" v-if="!checkingList || !checkingList.length">暂无数据</div>
        </div>
    </div>
</template>

<script>
    import _ from 'lodash';

    export default{
        props: {
            checkingList: {
                type: Array,
                default: function () {
                    return [];
                }
            },
            searchParam: {
                type: Object,
                default: function () {
                    return {
                        key_words: '',
                        page_items: 8,
                        page: 1,
                    };
                }
            }
        },

        watch: {
            'searchParam.key_words': function (newVal, oldVal) {
                this.onInputKeyWord(newVal);
            },
            'checkingList': function () {
                this.checkingList && this.checkingList.length && (this.onClickCheckingItem(this.checkingList[0],0));
            }
        },
        methods: {
            //选中审核数据
            onClickCheckingItem(checking, index){
                this.currentChecking = checking;
                this.$emit('onCheckingItemClick', checking, index);
            },

            //关键字搜索
            onInputKeyWord: _.debounce(function () {
                this.$emit('search', this.searchParam);
            }, 500),

            //刷新
            onRefreshBtnClick(){
                this.searchParam.page = 1;
                if (!this.searchParam.key_words) {
                    this.$emit('search', this.searchParam);
                    return;
                }
                this.searchParam.key_words = '';
            },
            // 滚动加载 
            onScroll(event){
                let offsetHeight = event.currentTarget.offsetHeight,
                    scrollHeight = event.target.scrollHeight,
                    scrollTop = event.target.scrollTop,
                    scrollBottom = offsetHeight + scrollTop;
                if(scrollBottom >= scrollHeight){
                    this.searchParam.page += 1;
                    this.$emit('search', this.searchParam);
                }
            },
        },
        data(){
            return {
                //当前所选审核
                currentChecking: {}
            };
        }
    }
</script>

