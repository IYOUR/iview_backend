<template>
    <Row class="checking">
        <i-col span="6" class="text-center checking-left">
            <div class="checking-header">
                <Badge :count="checkingList.length" class="badge">
                    <header>待审核</header>
                </Badge>
            </div>
            <checking-list :checkingList="checkingList"
                           :checking="currentChecking"
                           @onCheckingItemClick="selectChecking"
                           @search="search">
            </checking-list>
        </i-col>
        <i-col span="18" class="checking-right">
            <p class="checking-header">审核明细</p>
            <template v-if="checkingList && checkingList.length">
                <checking-detail v-if="!isEdit"
                                 :checking="currentChecking"
                                 @onRefresh="search"
                                 @onEditBtnClick="onEditBtnClick">
                </checking-detail>
                <checking-edit v-if="isEdit"
                               @onRefresh="search"
                               :checking="currentChecking">
                </checking-edit>
            </template>
        </i-col>
    </Row>
</template>
<script>
    import * as CheckingService from '../../../api/mall';
    import CheckingList from './components/CheckingList.vue';
    import CheckingDetail from './components/CheckingDetail.vue';
    import CheckingEdit from './components/CheckingEdit.vue';
    import {mapState, mapActions} from 'vuex';
    import isEmpty from 'lodash/isEmpty';

    export default {
        components: {
            CheckingList,
            CheckingDetail,
            CheckingEdit,
        },
        created(){
            this.currentPark.park_code && this.init();
        },
        methods: {
            init(){
                this.searchParam.key_words = '';
                this.searchParam.page = 1;
                this.searchParam.park_code = this.currentPark.park_code;
                this.getCheckingList(this.searchParam);
            },
            //获取审查列表
            getCheckingList(searchParam){
                return CheckingService.getCheckingList(searchParam).then(res => {
                    if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                        this.$Message.error(res.message || this.HTTP_STATUS.SERVER_ERROR.MSG);
                        return;
                    }
                    this.checkingList = res.data.items;
                    return this.checkingList;
                });
            },
            //选择审核列表
            selectChecking(checking){
                //todo  是否需要重置???
                this.isEdit = false;
                this.currentChecking = checking;
            },
            //搜索
            search(searchParam){
                this.searchParam = Object.assign({}, this.searchParam, searchParam);
                this.getCheckingList(this.searchParam).then(checkingList => {
                    checkingList && checkingList.length && this.selectChecking(checkingList[0]);
                });
            },
            //编辑审核信息
            onEditBtnClick(){
                this.isEdit = true;
            },
        },
        computed: {
            ...mapState({
                currentPark: 'activePark',
            }),
        },
        watch: {
            //级联更新
            'currentPark': function (park, oldVal) {
                !isEmpty(park) && this.init();
            }
        },
        data(){
            return {
                //查询条件
                searchParam: {
                    key_words: '',
                    page_items: 8,
                    page: 1,
                },
                //审查列表
                checkingList: [],
                //当前所审查详情
                currentChecking: {},
                //是否编辑
                isEdit: false,
            };
        }
    }
</script>

