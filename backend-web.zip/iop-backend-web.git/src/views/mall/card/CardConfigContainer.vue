<template>
    <Row>
        <i-col span="6" class="card-left">
            <CardConfigList :cardConfigList="cardConfigs"
                            @onCardItemClick="selectCard"
                            @onAddBtnClick="isAdd=true"></CardConfigList>
        </i-col>
        <i-col span="18" class="card-right">
            <CardConfigDetail v-if="!isAdd"
                              :cardIcons="cardIcons"
                              v-show="currentCard && currentCard.card_name"
                              :card="currentCard"></CardConfigDetail>
            <CardConfigAdd v-if="isAdd"
                           :cardIcons="cardIcons"
                           @onSuccess="addSuccess"></CardConfigAdd>
        </i-col>
    </Row>

</template>

<script>

    import * as MallService from '../../../api/mall';

    import CardConfigList from './components/CardConfigList.vue';
    import CardConfigDetail from './components/CardConfigDetail.vue';
    import CardConfigAdd from './components/CardConfigAdd.vue';

    import {mapState, mapActions, mapGetters} from 'vuex';

    export default {
        components: {
            CardConfigList,
            CardConfigDetail,
            CardConfigAdd,
        },
        created(){
            this.getCardIcons();
        },
        watch: {
            //级联更新
            'currentPark': function () {
                this.getCardConfigs();
            }
        },
        methods: {
            ...mapActions({
                getCardConfigs: 'getCardConfigs',
            }),
            selectCard(card){
                this.isAdd = false;
                this.currentCard = card;
            },
            addSuccess(){
                this.isAdd = !this.isAdd;
                this.getCardConfigs();
            },
            getCardIcons(){
                MallService.getCardIcons({size: 2}).then(res => {
                    if (res.code !== '1') {
                        return;
                    }
                    this.cardIcons = res.data.items
                });
            }
        },
        computed: {
            ...mapState({
                cardConfigs: 'cardConfigs',
                currentPark: 'activePark',
            }),
        },

        data(){
            return {
                currentCard: {},
                isAdd: false,
                cardIcons: [],
            }
        }
    }

</script>
