<template>
    <Row class="config-container">
        <i-col span="24" class="config-body">
            <Row class="router-header">
                <i-col span="6" class="no-select-border text-center">
                    <Select @on-change="onChange" 
                            v-model="cardType"
                            class="text">
                        <Option v-for="(item,index) in cardTypes" 
                                :value="item.value" 
                                :key="index">
                                {{item.text}}
                        </Option>
                    </Select>
                </i-col>
                <i-col span="18" class="text-center">
                    <span ref="title">配置明细</span>
                </i-col>
            </Row>
            <router-view class="router-body"></router-view>
        </i-col>
    </Row>
</template>
<style lang="scss">
    .no-select-border {
        .ivu-select-single .ivu-select-selection {
            border: none;
            outline: none;
        }
        .ivu-select {
            width: 100px;
        }
    }
</style>
<script>
    import Vue from 'vue';

    export default{
        methods: {
            onChange(path){
                this.$router.push({name: path});
                location.reload();
            }
        },
        data(){
            return {
                cardTypes: [
                    {text: '卡类别', value: 'iop.mall.card.type'},
                    {text: '卡名称', value: 'iop.mall.card.config'},
                ],
                cardType: this.$route.name || 'iop.mall.card.config'
            }
        }
    }
</script>