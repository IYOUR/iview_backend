<template>
    <Row>
        <i-col span="6" class="card-left">
            <CardTypeList :cardList="cardTypes" 
                          @onCardItemClick="selectCard"
                          @onAddBtnClick="isAdd = !isAdd">
            </CardTypeList>
        </i-col>
        <i-col span="18" class="card-right">
            <CardTypeDetail v-if="!isAdd" :card="currentCard"></CardTypeDetail>
            <CardTypeAdd v-if="isAdd"></CardTypeAdd>
        </i-col>
    </Row>

</template>
<script>
    import * as MallService from '../../../api/mall';

    import CardTypeList from './components/CardTypeList.vue';
    import CardTypeDetail from './components/CardTypeDetail.vue';
    import CardTypeAdd from './components/CardTypeAdd.vue';

    import {mapState, mapActions, mapGetters} from 'vuex';

    export default {
        components: {
            CardTypeList,
            CardTypeDetail,
            CardTypeAdd,
        },
        created(){
            //获取卡类型
            this.getCardTypes();
        },
        methods: {
            ...mapActions({
                getCardTypes: 'getCardTypes',
            }),
            selectCard(card){
                this.currentCard = card;
            },
        },
        computed: {
            ...mapState({
                cardTypes: 'cardTypes',
            }),
        },

        data(){
            return {
                currentCard: {},
                isAdd:false,
            }
        }
    }
</script>
