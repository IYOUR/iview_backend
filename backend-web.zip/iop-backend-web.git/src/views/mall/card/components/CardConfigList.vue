<template>
    <div class="card-config">
        <Row class="card-config-header">
            <i-col span="12">
                <Checkbox v-model="statusFilter" style="font-size: 14px;">显示未下架</Checkbox>
            </i-col>
            <i-col span="12" class="text-right">
                <a style="border-radius: 4px;padding:2px 10px;" 
                   @click="onAddBtnClick"
                   class="add-card">
                    <span>新建配置</span>
                    <i class="iconfont irain-xinjian2" style="font-size: 12px;"></i>
                </a>
            </i-col>
        </Row>

        <div class="checking-list checking-position">
            <div class="checking-item"
                 :class="{'active':item.card_conf_id===card.card_conf_id}"
                 v-for="(item, index) in getCardList"
                 @click="onCardItemClick(item)">
                <div class="image">
                    <img :src="item.ico_type" alt="" width="100%">
                </div>
                <div class="content">
                    <p class="title" v-text="item.card_name"></p>
                    <div class="description clearfix">
                        <span class="label">单价</span>
                        <span class="price">&yen;{{item.price / 100}}</span>
                    </div>
                </div>
            </div>
            <div class="checking-item text-center" v-if="!cardConfigList || !cardConfigList.length">暂无数据</div>
        </div>
    </div>
</template>


<script>
    export default{
        props: {
            cardConfigList: {
                type: Array,
                default: function () {
                    return [];
                }
            },
        },
        computed: {
            getCardList(){
                if (this.statusFilter) {
                    return this.cardConfigList.filter(item => item.card_status === '1');
                }
                return this.cardConfigList;
            }
        },
        watch: {
            cardConfigList: function () {
                //默认选择第一个
                this.cardConfigList.length && this.onCardItemClick(this.cardConfigList[0]);
                !this.cardConfigList.length && this.onCardItemClick({});
            }
        },
        methods: {
            onCardItemClick(card){
                this.card = card;
                this.$emit('onCardItemClick', card);
            },
            onAddBtnClick(){
                this.$emit('onAddBtnClick');
            }
        },
        data(){
            return {
                card: {},
                statusFilter: false,
            }
        },
    }
</script>

