<template>
    <Row class="card-config-detail">
        <i-form :rules="rules" :model="card" ref="cardTypeForm">
            <Row class="card-info card-from">
                <i-col span="24">
                    <i-col span="12">类型名称：</i-col>
                    <i-col span="12">状态：</i-col>
                </i-col>

                <i-col span="24">
                    <i-col span="12">
                        <Form-item prop="title">
                            <i-input v-model="card.title" placeholder="请输入类型名称"></i-input>
                        </Form-item>
                    </i-col>
                    <i-col span="12">
                        <Form-item>
                            <Select placeholder="请选择卡状态" v-model="card.t_status">
                                <Option v-for="(item,index) in cardStatus" :key="index" :value="item.value"
                                        v-text="item.text"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                </i-col>
            </Row>
            <div class="text-center card-submit-btn" style="margin-top: 20px;">
                <Button size="large" type="primary" style="margin-right: 40px;" @click.native="submitForm">确定</Button>
                <Button size="large" type="ghost" @click="close">取消</Button>
            </div>
        </i-form>

    </Row>
</template>
<script>
    import {mapState, mapActions} from 'vuex';
    //    import {isEmpty} from 'lodash';
    import * as UserService from '../../../../api/user';
    import * as MallService from '../../../../api/mall';

    export default {
        props: {
            card: {
                type: Object,
                default: function () {
                    return  {
                        t_status: '1'
                    };
                }
            }
        },
        created(){

        },
        computed: {
            ...mapState({
                cardStatus: 'cardStatus',
            }),
        },
        methods: {
            //表单提交
            submitForm(){
                this.$refs.cardTypeForm.validate(valid => {
                    valid && MallService.saveOrUpdateCardType(this.card).then(res => {
                        if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                            this.$Message.error('修改失败！');
                            return;
                        }
                         this.isEdit = !this.isEdit;
                        this.$Message.success('修改成功！');
                        location.reload();
                    });
                });
            },
            close(){
                this.$router.push('/mall/card/config');
            }
        },

        data () {
            return {
                isEdit: true,
                rules: {
                    title: [
                        {required: true, message: '类型名称不能为空', trigger: 'blur'},
                        {type: 'string', max: 50, message: '类型名称不能大于50字', trigger: 'blur'},
                    ]
                }
            }
        }
    }
</script>
