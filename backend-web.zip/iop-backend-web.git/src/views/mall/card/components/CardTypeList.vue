<template>
    <div class="card-config">
        <Row class="card-config-header">
            <i-col span="12">&nbsp;</i-col>
            <i-col span="12" class="text-right">
                <a style="border-radius: 4px;padding:2px 10px;" 
                   @click="onAddBtnClick"
                   class="add-card">
                    <span>新建类型</span>
                    <i class="iconfont irain-xinjian2" style="font-size: 12px;"></i>
                </a>
            </i-col>
        </Row>

        <div class="checking-list checking-position">
            <div class="checking-item"
                 :class="{'active':item.id===card.id}"
                 v-for="(item, index) in cardList"
                 @click="onCardItemClick(item)">
                <div class="content">
                    <p class="title" v-text="item.title"></p>
                    <div class="description clearfix">
                        <span class="label">已配置卡</span>
                        <span class="price" v-text="item.card_count"></span>
                    </div>
                </div>
            </div>

            <div class="checking-item text-center" v-if="!cardList || !cardList.length">暂无数据</div>

        </div>
    </div>
</template>


<script>
    export default{

        props: {
            cardList: {
                type: Array,
                default: function () {
                    return [];
                }
            },
        },
        watch: {
            cardList: function () {
                //默认选择第一个
                this.cardList && this.cardList.length && this.onCardItemClick(this.cardList[0]);
            }
        },
        methods: {
            onCardItemClick(card){
                this.card = card;
                this.$emit('onCardItemClick', card);
            },
            onAddBtnClick(){
                this.$emit('onAddBtnClick');
            }
        },
        data(){
            return {
                card: {},
            }
        },
    }
</script>

