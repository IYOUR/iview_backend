<template>
    <Row class="card-config-detail">

        <div class="card-name checking-list" v-if="!isEdit">
            <div class="checking-item">
                <div class="card-name-info">
                    <div class="image">
                        <img :src="currentCard.ico_type" alt="" width="100%">
                    </div>
                    <div class="content">
                        <p class="title" v-text="currentCard.card_name"></p>
                        <div class="description clearfix">
                            <span class="label">单价</span>
                            <span class="price">
                                <span>￥</span>
                                <span>{{currentCard.priceText}}</span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="card-color"></div>
            </div>
        </div>

        <!--编辑状态-->
        <div class="card-name checking-list" v-if="isEdit">
            <div class="checking-item">
                <div class="card-name-info">
                    <Dropdown trigger="click" @on-click="selectImage">
                        <a><img :src="otherParam.icoType" alt="" width="100%"></a>
                        <Dropdown-menu slot="list" style="overflow:auto;height: 300px;">
                            <Dropdown-item v-for="(icon,index) in cardIcons" :key="index" :name="icon">
                                <img :src="icon" alt="" width="100%">
                            </Dropdown-item>
                            <Dropdown-item v-if="cardIcons.length === 0" disabled>暂无图标</Dropdown-item>
                        </Dropdown-menu>
                    </Dropdown>
                    <div class="content">
                        <p class="title" v-text="currentCard.card_name"></p>
                        <div class="description clearfix">
                            <span class="label">单价</span>
                            <span class="price">
                                <span>￥</span>
                                <i-input size="small" v-model="currentCard.priceText"
                                         style="display: inline-block;width: 60px;"></i-input>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="card-color"></div>
            </div>
        </div>


        <div class="clearfix edit-btn" :style="{visibility:!isEdit ? 'visible' :'hidden'}">
            <i class="iconfont irain-edit fr" @click="isEdit=!isEdit"></i>
        </div>

        <Row class="card-info" v-if="!isEdit">
            <i-col span="24">
                <i-col span="12">类型：</i-col>
                <i-col span="12">状态：</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="currentCard.type_name"></i-col>
                <i-col span="12" v-text="currentCard.cardStatusText"></i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12">有效期：</i-col>
                <i-col span="12">有限时段：</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="currentCard.expiryText"></i-col>
                <i-col span="12" v-text="currentCard.expiryTimeText"></i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12">总量：</i-col>
                <i-col span="12">库存：</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="currentCard.total_stock"></i-col>
                <i-col span="12" v-text="currentCard.stock"></i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12">是否审核：</i-col>
                <i-col span="12">停车场名称：</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="currentCard.cardIsCheckingText"></i-col>
                <i-col span="12" v-text="currentCard.card_update_time && parkInfo.parking_name"></i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12">创建时间：</i-col>
                <i-col span="12">最后修改时间：</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="currentCard.card_createon"></i-col>
                <i-col span="12" v-text="currentCard.card_update_time"></i-col>
            </i-col>
        </Row>

        <!--编辑状态-->
        <i-form v-if="isEdit" :rules="rules" :model="card" ref="cardFrom">
            <Row class="card-info card-from">
                <i-col span="24">
                    <i-col span="12">类型：</i-col>
                    <i-col span="12">状态：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12" v-text="currentCard.type_name"></i-col>
                    <i-col span="12">
                        <Form-item>
                            <Select placeholder="请选择卡状态" v-model="currentCard.card_status">
                                <Option v-for="(item,index) in cardStatus" :key="index" :value="item.value"
                                        v-text="item.text"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">有效期：</i-col>
                    <i-col span="12">有限时段：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12" v-text="currentCard.expiryTypeText"></i-col>
                    <i-col span="12">123</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">总量：</i-col>
                    <i-col span="12">库存：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">
                        <Form-item prop="total_stock">
                            <i-input placeholder="请输入总量" v-model.number="currentCard.total_stock"></i-input>
                        </Form-item>
                    </i-col>
                    <i-col span="12" v-text="currentCard.copyStock"></i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">是否审核：</i-col>
                    <i-col span="12">停车场名称：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">
                        <Form-item>
                            <Select placeholder="是否审核" v-model="currentCard.need_review">
                                <Option v-for="(item,index) in isChecking" :value="item.value" v-text="item.text"
                                        :key="index"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                    <i-col span="12" v-text="parkInfo.parking_name"></i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">创建时间：</i-col>
                    <i-col span="12">最后修改时间：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12" v-text="currentCard.card_createon"></i-col>
                    <i-col span="12" v-text="currentCard.card_update_time"></i-col>
                </i-col>
            </Row>
            <div class="text-center card-submit-btn" style="margin-top: 20px;">
                <Button size="large" type="primary" style="margin-right: 40px;" @click.native="submitForm">确定</Button>
                <Button size="large" type="ghost" @click.native="onCancelBtnClick">取消</Button>
            </div>
        </i-form>
    </Row>
</template>
<script>
    import {mapState, mapActions} from 'vuex';
    import {isEmpty} from 'lodash';
    import * as UserService from '../../../../api/user';
    import * as MallService from '../../../../api/mall';

    export default {

        props: {
            card: {
                type: Object,
            },
            cardIcons: {
                type: Array,
                default: function () {
                    return [];
                }
            },
        },
        computed: {
            ...mapState({
                cardStatus: 'cardStatus',
                isChecking: 'isChecking',
                cardUnit: 'cardUnit',
            }),
        },
        methods: {
            //数据处理
            processCard(card){
                if (isEmpty(card)) {
                    return {};
                }
                card.id = card.card_conf_id;
                //卡状态
                card.cardStatusText = this.cardStatus.find(item => item.value === card.card_status).text || '';
                //是否审核
                card.cardIsCheckingText = this.isChecking.find(item => item.value === card.need_review).text || '';
                //价格
                card.priceText = (card.price / 100);
                card.totalStock = parseInt(card.total_stock, 10);
                card.stock = parseInt(card.stock, 10);
                card.copyStock = parseInt(card.stock, 10);
                //有效期
                card.expiryText = card.expiry_count + this.cardUnit.find(item => item.value === card.expiry_type).text || '';
                //有效时间段
                card.expiryTimeText = `${this.fixZero(card.time_start)}:00 - ${this.fixZero(card.time_end)}:00`;

                //icon
                this.otherParam.icoType = card.ico_type;
            },
            //参数校验
            validParam(){
                this.card.priceText+='';

                if (!this.card.priceText || !this.card.priceText.trim()) {
                    return '请输入价格！';
                }

                if (!/^\+?[1-9][0-9]*$/.test(this.card.priceText)) {
                    return '价格为正整数！';
                }
            },
            //表单提交
            submitForm(){
                let msg;
                if (msg = this.validParam()) {
                    this.$Message.info(msg);
                    return;
                }

                this.$refs.cardFrom.validate(valid => {
                    this.currentCard.ico_type = this.otherParam.icoType;
                    this.currentCard.price = this.currentCard.priceText * 100;
                    valid && MallService.saveOrUpdateCardConfig(this.currentCard).then(res => {
                        if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                            this.$Message.error('修改失败！');
                            return;
                        }
                        this.isEdit = !this.isEdit;
                        this.$Message.success('修改成功！');
                        window.location.reload();
                    });
                });
            },
            //数据格式处理
            fixZero(num){
                return parseInt(num, 10) < 10 ? `0${num}` : num;
            },
            //选择图片
            selectImage(src){
                src && (this.otherParam.icoType = src);
            },
            //取消按钮事件
            onCancelBtnClick(){
                //还原数据
                this.currentCard = Object.assign({},this.copyCard);
                //切换状态
                this.isEdit = !this.isEdit;
                this.copyCard = {};
            }

        },
        watch: {
            'card': function (card) {
                this.currentCard = card; 
                this.processCard(this.currentCard);
                this.copyCard =  Object.assign({},this.currentCard);
            },
            'card.total_stock': function (newVal, oldVal) {
                if (newVal > this.card.stock) {
                    this.card.copyStock = parseInt(this.card.stock, 10) + (newVal - this.card.totalStock);
                } else {
                    this.card.copyStock = this.card.stock;
                }
            }
        },
        data () {

            //总量校验
            const totalStockValidator = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error('总量不能为空或零！'));
                }
                if (!/^\+?[1-9][0-9]*$/.test(value)) {
                    return callback(new Error('请输入非零整整数!'));
                }
                if (value < this.card.stock) {
                    return callback(new Error('总量必须大于等于库存量!'));
                }
                return callback();
            };

            return {
                isEdit: false,
                isSelectImage: false,
                parkInfo: UserService.getUserSelectPark(),
                rules: {
                    total_stock: [
                        {validator: totalStockValidator, trigger: 'blur'}
                    ],
                },
                disabledMinutes: (function () {
                    let arr = [];
                    for (let i = 1; i <= 60; i++) {
                        arr.push(i);
                    }
                    return arr;
                })(),
                otherParam: {
                    icoType: 'http://180.97.80.42:8000/public/icon_weekend@2x.png',
                },
                //复制一份数据
                copyCard:{},
                currentCard:{},
            }
        }
    }
</script>
