<template>
    <Row class="card-config-detail">

        <!--编辑状态-->
        <div class="card-name checking-list">
            <div class="checking-item">
                <div class="card-name-info">
                    <Dropdown trigger="click" @on-click="selectImage">
                        <a><img :src="otherParam.icoType" alt="" width="100%"></a>
                        <Dropdown-menu slot="list" style="overflow:auto;height: 300px;">
                            <Dropdown-item v-for="(icon,index) in cardIcons" 
                                           :key="index" 
                                           :name="icon">
                                <img :src="icon" alt="" width="100%">
                            </Dropdown-item>
                            <Dropdown-item v-if="cardIcons.length === 0" disabled>暂无图标</Dropdown-item>
                        </Dropdown-menu>
                    </Dropdown>

                    <div class="content">
                        <p class="title">
                            <i-input size="small" 
                                     style="display: inline-block;width: 115px;"
                                     v-model="card.card_name">
                            </i-input>
                        </p>
                        <div class="description clearfix">
                            <span class="label">单价</span>
                            <span class="price">
                                <span>￥</span>
                                    <i-input size="small"
                                             style="display: inline-block;width: 60px;margin-bottom: 0;"
                                             v-model.number="card.copyPrice">
                                    </i-input>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="card-color"></div>
            </div>
        </div>

        <!--编辑状态-->
        <Form :rules="rules" :model="card" ref="cardFrom">
            <Row class="card-info card-from">
                <i-col span="24">
                    <i-col span="12">类型：</i-col>
                    <i-col span="12">状态：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">
                        <Form-item prop="type_id">
                            <Select placeholder="请选择卡类别" v-model="card.type_id">
                                <Option v-for="(item,index) in cardTypes"
                                        :value="item.id" :key="index"
                                        v-text="item.title"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                    <i-col span="12">
                        <Form-item>
                            <Select placeholder="请选择卡状态" 
                                    v-model="card.card_status">
                                <Option v-for="(item,index) in cardStatus" 
                                        :key="index" 
                                        :value="item.value"
                                        v-text="item.text">
                                </Option>
                            </Select>
                        </Form-item>
                    </i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">有效期：</i-col>
                    <i-col span="12">有限时段：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">
                        <form-item style="width:120px;display: inline-block;" 
                                   prop="expiry_count">
                            <i-input placeholder="请输入有效数值" 
                                     v-model="card.expiry_count">
                            </i-input>
                        </form-item>
                        <form-item style="width:120px;display: inline-block;" 
                                    prop="expiry_type">
                            <Select placeholder="请选择时间段单位" 
                                    v-model="card.expiry_type">
                                <Option v-for="(item,index) in cardUnit" 
                                        :key="index" 
                                        :value="item.value"
                                        v-text="item.text">
                                </Option>
                            </Select>
                        </form-item>
                    </i-col>
                    <i-col span="12">
                        <Form-item prop="time">
                            <Time-picker v-model="card.time"
                                         format="HH:mm" type="timerange"
                                         hide-disabled-options
                                         :disabled-minutes="disabledMinutes"
                                         placeholder="选择有限时段"></Time-picker>
                        </Form-item>
                    </i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">总量：</i-col>
                    <i-col span="12">库存：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">
                        <Form-item prop="total_stock">
                            <i-input placeholder="请输入总量" 
                                     v-model="card.total_stock">
                            </i-input>
                        </Form-item>
                    </i-col>
                    <i-col span="12">
                        <Form-item prop="stock">
                            <i-input placeholder="请输入总量" 
                                     v-model="card.stock">
                            </i-input>
                        </Form-item>
                    </i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">是否审核：</i-col>
                    <i-col span="12">停车场名称：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12">
                        <Form-item>
                            <Select placeholder="是否审核" v-model="card.need_review">
                                <Option v-for="(item,index) in isChecking" 
                                        :value="item.value" 
                                        v-text="item.text"
                                        :key="index">
                                </Option>
                            </Select>
                        </Form-item>
                    </i-col>
                    <i-col span="12">
                        <Form-item prop="park_code">
                            <Select placeholder="请选择停车场" v-model="card.park_code">
                                <Option v-for="(item,index) in carParks"
                                        :value="item.park_code" :key="index"
                                        v-text="item.parking_name || '未命名车场'"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                </i-col>
            </Row>
        </Form>
        <div class="text-center card-submit-btn" style="margin-top: 20px;">
            <Button size="large" 
                    type="primary" 
                    style="margin-right: 40px;"
                    @click.native="submitForm">
                    提交
             </Button>
        </div>

    </Row>
</template>
<script>
    import {mapState, mapActions} from 'vuex';
    import {isEmpty} from 'lodash';
    import * as UserService from '../../../../api/user';
    import * as MallService from '../../../../api/mall';

    export default {
        props: {
            cardIcons: {
                type: Array,
                default: function () {
                    return [];
                }
            },
        },
        created(){
            this.getCardTypes({t_status:1});
            this.getParkList();
        },
        computed: {
            ...mapState({
                cardStatus: 'cardStatus',
                isChecking: 'isChecking',
                cardUnit: 'cardUnit',
                carParks: 'carParks',
                cardTypes: 'cardTypes',
            }),
        },
        methods: {
            ...mapActions({
                getCardTypes: 'getCardTypes',
                getParkList: 'getParkList',
            }),

            //数据处理
            processCard(){
                this.card.ico_type = this.otherParam.icoType;
                this.card.price = parseInt(this.card.copyPrice, 10) * 100;
                this.card.time_start = moment(this.card.time[0]).hour();
                this.card.time_end = moment(this.card.time[1]).hour();
                delete this.card.copyPrice;
                delete this.card.time;
                return true;
            },

            //表单提交
            submitForm(){
                if (!this.card.card_name) {
                    this.$Message.error('卡名称不能为空！');
                    return;
                }

                if (this.card.card_name.trim().length < 3) {
                    this.$Message.error('卡名称不能少于三位！');
                    return;
                }

                if (!this.card.copyPrice) {
                    this.$Message.error('卡价格不能为空！');
                    return;
                }

                if (!/^\+?[1-9][0-9]*$/.test(this.card.copyPrice)) {
                    this.$Message.error('卡价格必须位数字！');
                    return;
                }

                this.$refs.cardFrom.validate(valid => {
                    valid && this.processCard() && MallService.saveOrUpdateCardConfig(this.card).then(res => {
                        if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                            this.$Message.error('修改失败！');
                            return;
                        }
                        this.$emit('onSuccess');
                    });
                });
            },

            fixZero(num){
                return parseInt(num, 10) < 10 ? `0${num}` : num;
            },

            //选择图片
            selectImage(src){
                src && (this.otherParam.icoType = src);
            },

        },

        data () {

            //总量校验
            const totalStockValidator = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error('总量不能为空或零！'));
                }
                if (!/^\+?[1-9][0-9]*$/.test(value)) {
                    return callback(new Error('请输入非零整整数!'));
                }
                if (value < this.card.stock) {
                    return callback(new Error('总量必须大于等于库存量!'));
                }
                return callback();
            };

            return {
                card: {
                    need_review: '0',
                    card_status: '1',
                    expiry_type: '2',
                    stock: '',
                    time: [],
                    ico_type: 'icon_weekend@2x.png',
                },
                rules: {
                    total_stock: [
                        {validator: totalStockValidator, trigger: 'blur'}
                    ],
                    stock: [
                        {required: true, message: '库存不能为空', trigger: 'blur'}
                    ],
                    type_id: [
                        {required: true, message: '请选择卡类别', trigger: 'change'}
                    ],
                    expiry_count: [
                        {required: true, message: '有效数值不能为空', trigger: 'blur'}
                    ],
                    park_code: [
                        {required: true, message: '请选择车场', trigger: 'change'}
                    ],
                    time: [
                        {required: true, type: 'array', message: '请选择有效时间段', trigger: 'change'}
                    ],
                    name: [
                        {required: true, message: '姓名不能为空', trigger: 'blur'}
                    ],
                },
                disabledMinutes: (function () {
                    let arr = [];
                    for (let i = 1; i <= 60; i++) {
                        arr.push(i);
                    }
                    return arr;
                })(),
                otherParam: {
                    time: [],
                    price: '',
                    icoType: 'http://180.97.80.42:8000/public/icon_weekend@2x.png',
                }
            }
        }
    }
</script>
<style lang="scss">
    .ivu-dropdown {

        width: 50px;

        + .content {
            display: inline-block;
        }

        .ivu-dropdown-item {
            img {
                width: 50px;
            }
        }
        .ivu-select-dropdown {
            width: auto;
            text-align: center;
        }
    }

    .ivu-dropdown-item {
        padding: 0;
    }
</style>