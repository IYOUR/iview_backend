<template>
    <div class="select-img">
        <div :class="['item',{'active':index === currentIndex}]" v-for="(item,index) in images" @click="onClickImageItem(item,index)">
            <img src="../../../../assets/image/icon-down-small@3X.png" alt=""/>
        </div>
    </div>
</template>
<style scoped lang="scss">
    .select-img {
        list-style: none;
        font-size: 0;

        .item {
            display: inline-block;
            font-size: 14px;
            position: relative;
            width: 50px;
            height: 50px;
            border-radius: 5px;
            margin-right: 20px;
            border: 1px solid transparent;
            cursor: pointer;
            &:hover,
            &.active {
                border: 1px solid #d2ccf3;
            }
        }
    }
</style>
<script>
    export default {
        props: {
            images: {
                type: Array,
                default: function () {
                    return [1, 2, 3];
                }
            }
        },
        created(){

        },
        methods: {
            onClickImageItem(image,index){
                this.currentIndex = index;
                this.$emit('on');
            }
        },
        data () {
            return {
                currentIndex:null
            }
        }
    }
</script>
