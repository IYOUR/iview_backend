<template>
    <Row class="card-config-detail">

        <div class="clearfix edit-btn" :style="{visibility:!isEdit ? 'visible' :'hidden'}">
            <i class="iconfont irain-edit fr" @click="isEdit=!isEdit"></i>
        </div>

        <Row class="card-info" v-if="!isEdit">
            <i-col span="24">
                <i-col span="12">类型名称：</i-col>
                <i-col span="12">状态：</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="card.title || '--'"></i-col>
                <i-col span="12" v-text="getCardStatus || '--'"></i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12">已配置卡：</i-col>
                <i-col span="12">&nbsp;</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="card.card_count || '--'"></i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12">创建时间：</i-col>
                <i-col span="12">最后修改时间：</i-col>
            </i-col>
            <i-col span="24">
                <i-col span="12" v-text="card.createon || '--'"></i-col>
                <i-col span="12" v-text="card.update_time || '--'"></i-col>
            </i-col>
        </Row>

        <!--编辑状态-->
        <i-form v-if="isEdit" :rules="rules" :model="card" ref="cardTypeForm">
            <Row class="card-info card-from">
                <i-col span="24">
                    <i-col span="12">类型名称：</i-col>
                    <i-col span="12">状态：</i-col>
                </i-col>

                <i-col span="24">
                    <i-col span="12">
                        <Form-item prop="title">
                            <i-input v-model="card.title" placeholder="请输入类型名称"></i-input>
                        </Form-item>
                    </i-col>
                    <i-col span="12">
                        <Form-item>
                            <Select placeholder="请选择卡状态" v-model="card.t_status">
                                <Option v-for="(item,index) in cardStatus" :key="index" :value="item.value"
                                        v-text="item.text"></Option>
                            </Select>
                        </Form-item>
                    </i-col>
                </i-col>

                <i-col span="24">
                    <i-col span="12">已配置卡：</i-col>
                    <i-col span="12">&nbsp;</i-col>
                </i-col>

                <i-col span="24">
                    <i-col span="12" v-text="card.card_count || '--'"></i-col>
                </i-col>

                <i-col span="24">
                    <i-col span="12">创建时间：</i-col>
                    <i-col span="12">最后修改时间：</i-col>
                </i-col>
                <i-col span="24">
                    <i-col span="12" v-text="card.createon"></i-col>
                    <i-col span="12" v-text="card.update_time"></i-col>
                </i-col>
            </Row>
            <div class="text-center card-submit-btn" style="margin-top: 20px;">
                <Button size="large" type="primary" style="margin-right: 40px;" @click.native="submitForm">确定</Button>
                <Button size="large" type="ghost" @click.native="isEdit=!isEdit">取消</Button>
            </div>
        </i-form>

    </Row>
</template>
<script>
    import {mapState, mapActions} from 'vuex';
    //    import {isEmpty} from 'lodash';
    import * as UserService from '../../../../api/user';
    import * as MallService from '../../../../api/mall';

    export default {
        props: {
            card: {
                type: Object,
                default: function () {
                    return {};
                }
            }
        },
        created(){

        },
        computed: {
            ...mapState({
                cardStatus: 'cardStatus',
            }),
            //状态获取
            getCardStatus(){
                return this.card.t_status && this.cardStatus.find(item => item.value === this.card.t_status).text || '';
            },
        },
        methods: {
            //表单提交
            submitForm(){
                this.$refs.cardTypeForm.validate(valid => {
                    valid && MallService.saveOrUpdateCardType(this.card).then(res => {
                        if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                            this.$Message.error('修改失败！');
                            return;
                        }
                        this.isEdit = !this.isEdit;
                        this.$Message.success('修改成功！');
                    });
                })
            },

            fixZero(num){
                return parseInt(num, 10) < 10 ? `0${num}` : num;
            }

        },
        watch: {
        },
        data () {

            return {
                isEdit: false,
                parkInfo: UserService.getUserSelectPark(),
                disabledMinutes: (function () {
                    let arr = [];
                    for (let i = 1; i <= 60; i++) {
                        arr.push(i);
                    }
                    return arr;
                })(),
                copyCard: {},
                rules: {
                    title: [
                        {required: true, message: '类型名称不能为空', trigger: 'blur'},
                        {type: 'string', max: 50, message: '类型名称不能大于50字', trigger: 'blur'},
                    ]
                }
            }
        }
    }
</script>
