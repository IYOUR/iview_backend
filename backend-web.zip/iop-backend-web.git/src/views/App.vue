<template>
    <div class="main">
        <!--左边菜单-->
        <div class="left-box">
            <ul class="left-content menus">
                <li class="menu-item logo">
                    <img src="../assets/image/IOP logo@3X.png" alt="图片无法正常加载。请刷新重试！">
                </li>
                <router-link :to="{name: 'iop.total'}" active-class="menu-active">
                    <li class="menu-item">
                        <p><i class="iconfont irain-shujuguanli"></i></p>
                        <p>数据管理</p>
                    </li>
                </router-link>
                <router-link :to="{name: 'iop.mall'}" active-class="menu-active">
                    <li class="menu-item">
                        <p><i class="iconfont irain-cf-c36"></i></p>
                        <p>商城管理</p>
                    </li>
                </router-link>  
                <router-link :to="{name: 'iop.group.edit'}"
                             active-class="menu-active">
                    <li class="menu-item">
                        <p><i class="iconfont irain-jituanguanli"></i></p>
                        <p>集团管理</p>
                    </li>
                </router-link>
            </ul>
        </div>
        <!--右边内容区域-->
        <div class="right-content">
            <header class="header clearfix">
                <div class="header-left clearfix">
                    <div class="title">停车王-智慧管理系统</div>
                    <Select class="select" placeholder="请选择车场"
                            v-model="currentPark.park_code">
                        <Option v-for="item in carList"
                                :value="item.park_code"
                                :key="item">
                            {{ item.parking_name }}
                        </Option>
                    </Select>
                </div>
                <div class="header-right">
                    <ul class="header-list clearfix">
                        <li>
                            <a href="javascript:;">
                                <i class="iconfont irain-yonghu"></i>
                                <span>{{userInfo.username}}</span>
                            </a>
                        </li>
                        <router-link :to="{name:'iop.setup'}"
                                     active-class="menu-active">
                            <li>
                                <a href="javascript:;">
                                    <i class="iconfont irain-shezhi2"></i>
                                    <span>设置</span>
                                </a>
                            </li>
                        </router-link>
                        <li>
                            <a @click="logout">
                                <i class="iconfont irain-exit "></i>
                                <span>注销</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </header>
            <router-view></router-view>
        </div>
    </div>
</template>

<script>
    import * as UserService from '../api/user';
    import {mapState, mapActions} from 'vuex';
    import {CHANGE_ACTIVE_PARK} from '../store/mutation-types';

    export default {
        created () {
            this.getParkList().then(res => {
                if (res.code !== this.HTTP_STATUS.SUCCESS.CODE) {
                    this.$Message.error(res.message || this.HTTP_STATUS.SERVER_ERROR.MSG);
                    return;
                }
                //todo 先本地获取，如果存在新的数据中，选中。 不存在 默认第一个
                res.data && res.data.length && this.$store.commit(CHANGE_ACTIVE_PARK, res.data[0]);
            });
        },
        methods: {
            //获取车场列表
            ...mapActions({
                getParkList: 'getParkList',
            }),
            //退出登录
            logout(){
                UserService.logout();
                location.reload();
            },
        },
        computed: {
            ...mapState({
                carList: 'carParks',
                currentPark: 'activePark',
            }),
        },
        watch: {
            'currentPark.park_code': function (park_code) {
                if (park_code) {
                    let park = this.carList.find(item => item.park_code === park_code);
                    UserService.setUserSelectPark(park);
                    this.$store.commit(CHANGE_ACTIVE_PARK, UserService.getUserSelectPark());
                }
            }
        },
        data () {
            return {
                userInfo: UserService.getUser(),
            }
        }
    }

</script>
